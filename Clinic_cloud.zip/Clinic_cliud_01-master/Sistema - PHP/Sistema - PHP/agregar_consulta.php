<?php 
$path_css="css/";
$path_js="";
 ?>

  <!-- CONECCION A LA BASE DE DATOS -->
  <?php 
include "funciones/conecxion.php";
include "guardar_archivo.php";
if (!$conn=conn_Star()) {
    header("location:error.php");
  }
  ?>
<!-- VALIDAR LOGEO -->
<?php 
  session_start();
  if (!isset($_SESSION["nombre"])){
     header("Location:logeo.php");
  }
  if (isset($_GET["id_paciente"])){
    $id_paciente=$_GET["id_paciente"];
  //  echo $id_paciente."<-post<br>";
     //header("Location:error.php");
  }
  if (isset($_POST["id_paciente"])){
    $id_paciente=$_POST["id_paciente"];
   // echo $id_paciente."<-get<br>";

  }

 ?>





<!-- CARGAR CONSULTA -->
<?php 
if (isset($_POST["asunto"])) {


  //echo $_POST['comentarios']."<br>";
  //echo $_POST['asunto']."<br>";
  $hoy = date("d/m/y"); 

  $sql="INSERT INTO `c_c_santino_01`.`consultas` (`id_especialista`, `id_paciente`, `fecha`, `observaciones`, `asunto`) VALUES ('".$_SESSION["id_usuario"]."', '".$_POST['id_paciente']."', '".$hoy."', '".$_POST["comentarios"]."', '".$_POST['asunto']."');";
    

  //  echo $sql;
  if(agregar($sql,$conn))
      header("Location:turnos_redux.php");
  else
     // header("Location:error.php");


      //  echo "este es_".$id_paciente."_<-";
   guardar_archivo($id_paciente,"img/estudios/");

//END FILE___________________________________________________
}
 ?>

 <?php 
//FILE________________________________________________________




  ?>

<!-- CARGAR CONSULTA -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
        <?php include "funciones/header.html" ?>


    <link href="https://fonts.googleapis.com/css?family=Roboto:300" rel="stylesheet">

    
    <link rel="stylesheet" type="text/css" href="<?php echo $path_css; ?>estilos_generales.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo $path_css; ?>estilos_consulta.css" />


  <script type="text/javascript" src="<?php echo $path_js; ?>jquery-3.3.1.min.js"></script>

  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >
  <link rel="stylesheet" type="text/css" href="css/font.css">

  <script>
        function Mostrar() {
            document.getElementById("menu").style.display = "block";
            document.getElementById("cuerpo").style.marginLeft = "230px";
        }

        function Ocultar() {
            document.getElementById("menu").style.display = "none";
            document.getElementById("cuerpo").style.marginLeft = "0px";
        }

        function Mostrar_Ocultar() {
          var menu=document.getElementById("menu");

          if (menu.style.display=="none") {
            Mostrar();
          }else{
            Ocultar();
          }
        }
    </script>

    <script type="text/javascript">
      /*conultas-estudios y demas*/
    $(document).ready(function(){
    $(".lista-body").hide();
    $(".lista-header").click(function(event){
             var desplegable = $(this).next();
             $('.lista-body').not(desplegable).slideUp('fast');
              desplegable.slideToggle('fast');
              event.preventDefault();
              })
        });

    /*consultas pasadas*/
    function acordion(){
        //alert("asi");
        $(".info-body").hide();
        $(".info-header").click(function(event){
             var desplegable = $(this).next();
             $('.info-body').not(desplegable).slideUp('fast');
              desplegable.slideToggle('fast');
              event.preventDefault();
              });
      } 
    $(document).ready(function(){
        mostrar_historial_consultas(<?php echo $id_paciente; ?>);
        });
  </script>

</head>
<body>


<div class="container">

  <?php 
include "menu.php";
 ?>     
    <section class="cuerpo" id="cuerpo">
      <h2> 
        <a id="abrir" class="abrir-cerrar" href="javascript:void(0)" onclick="Mostrar_Ocultar()">
              <div class="abrir-menu"><i class="fas fa-align-justify"></i></div>
          </a>

          Pacientes

        <img  class="logo-responsive" src="img/logo.png" alt="">
      </h2>

      <div class="container-cunsulta">
     <form action="agregar_consulta.php" method="POST" enctype="multipart/form-data">
        <div class="datos-paciente-consulta">

            <div class="configuracion-consulta">
              <button><i class="fa fa-ellipsis-h" aria-hidden="true"></i></button>
                <input type="hidden" name="id_paciente" value="<?php echo $id_paciente;?>">
            <!--  <button onclick="agregar_consulta( TERMINAR CONSULTA</button>-->
              <input type="submit" name="btn" class="button" value="TERMINAR CONSULTA">
              <div class="ops-consulta">
              </div>

            </div>
         

        </div>

        <div class="consulta">

          <div class="content-consulta asunto-consulta">
            <div class="content-title ">
              Asunto
            </div>
            <div class="content-body">
              <input type="text" name="asunto" id="asunto">
            </div>
          </div>

          <div class="content-consulta discripcion-consulta">
            <div class="content-title">
              Descripcion

            </div>
            <div class="content-body">
              <textarea name="comentarios" rows="10" cols="40" placeholder="Escribir consulta" id="descripcion"></textarea>
            </div>
          </div>

          <div class="content-consulta archivo-consulta">
            <div class="content-title">
              Cargar examen
            </div>
            <div class="content-body">
              <div class="input-estudio">
                <input type="file" class="" name="archivo[]">
              </div>
            </div>
          </div>
              
        </div>
      </form>
      </div>

      <div class="detalles-consulta">
        <div class="title-resumen-clinico">
          <i class="fa fa-times" aria-hidden="true"></i> Resumen Clinico <a href="javascript:" ><i class="fa fa-print" aria-hidden="true"></i>Imprimir</a>
        </div>
          <div class="box-lista">
            <div class="lista-header">
              <div class="nombre-lista"><i class="fa fa-calendar-alt" aria-hidden="true"></i>Consultas Pasadas</div>
                <i class="fa fa-caret-down" aria-hidden="true"></i>
            </div>
            <div class="lista-body">

            
              

               
                <div id="h_ag_paciente">
                  
                </div>



            </div>
          </div>





          <div class="box-lista">
            <div class="lista-header">
              <div class="nombre-lista"><i class="fa fa-clipboard-list" aria-hidden="true"></i>Antesedentes Clinicos </div>
               <i class="fa fa-caret-down" aria-hidden="true"></i>
            </div>
            <div class="lista-body">
              Lorem ipsum dolor sit amet, consectetur adipisicing elit. Temporibus omnis officia nobis commodi error illum aut neque ullam sunt quia eaque labore, nisi dolores numquam corrupti est necessitatibus voluptates doloribus!
            </div>
          </div>
          <div class="box-lista">
            <div class="lista-header">
              <div class="nombre-lista"><i class="fa fa-book" aria-hidden="true"></i>Estudios Clinicos</div>
              <i class="fa fa-caret-down" aria-hidden="true"></i>
            </div>
            <div class="lista-body">
              Lorem ipsum dolor sit amet, consectetur adipisicing elit. Temporibus omnis officia nobis commodi error illum aut neque ullam sunt quia eaque labore, nisi dolores numquam corrupti est necessitatibus voluptates doloribus!
              Lorem ipsum dolor sit amet, consectetur adipisicing elit. Temporibus omnis officia nobis commodi error illum aut neque ullam sunt quia eaque labore, nisi dolores numquam corrupti est necessitatibus voluptates doloribus!
              Lorem ipsum dolor sit amet, consectetur adipisicing elit. Temporibus omnis officia nobis commodi error illum aut neque ullam sunt quia eaque labore, nisi dolores numquam corrupti est necessitatibus voluptates doloribus!
            </div>
          </div>
      </div>

    
    </section>




</div>

<!-- AGUS-->
<script>

        
</script>


<script src="js/controlador_ajax.js"></script>
<scripst src="js/jquery.min.js"></scripst>

  
</body>
</html>