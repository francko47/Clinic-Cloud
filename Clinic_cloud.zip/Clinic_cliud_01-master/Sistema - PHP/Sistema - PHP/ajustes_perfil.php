<?php 
  $path_css="css/";
  $path_js="";
?>

  <!-- CONECCION A LA BASE DE DATOS -->
  <?php 
include "funciones/conecxion.php";
include "guardar_archivo.php";
include 'funciones/f_ajuste_perfil.php';
if (!$conn=conn_Star()) {
    header("location:error.php");
  }
  ?>
<!-- VALIDAR LOGEO -->
<?php 
  session_start();
  if (!isset($_SESSION["nombre"])){
     header("Location:logeo.php");
  }
 ?>
 <?php 
 $especialista=$_SESSION["id_usuario"];

  ?>
<?php 
if (isset($_POST["btn_guardar_e"])) {
  $dni=$_POST["dni"];
  $fecha_nac=$_POST["fecha_nac"];
  $sexo=$_POST["sexo"];
  $celular=$_POST["celular"];
  $pass=$_POST["pass"];
  $especialidad=$_POST["especialidad"];
  modificar_datos($conn,$especialista,$dni,$fecha_nac,$sexo,$celular,$pass,$especialidad);
  if ($_FILES["archivo"]["name"][0]) {
    modificar_foto($conn,$especialista);
  }
   guardar_archivo($especialista,"img/photo_perfil/");
}
?>

<?php
  header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
  header("Expires: Sat, 1 Jul 2000 05:00:00 GMT"); // Fecha en el pasado
?>
  <?php 
  //CARGA DATOS
    $valores=cargar_datos($conn,$especialista);

    $nombre_c=$valores[3]." ".$valores[4];
   ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
        <?php include "funciones/header.html" ?>
  <!--CACHE -->
      <meta http-equiv="Expires" content="0">
      <meta http-equiv="Last-Modified" content="0">
      <meta http-equiv="Cache-Control" content="no-cache, mustrevalidate">
      <meta http-equiv="Pragma" content="no-cache">
  <!--CACHE -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300" rel="stylesheet">

		
		<link rel="stylesheet" type="text/css" href="<?php echo $path_css;?>estilos_generales.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo $path_css;?>estilos_ajustes_perfil.css" />


  <script type="text/javascript" src="<?php echo $path_js; ?>ajustes_perfil.js"></script>

	<script type="text/javascript" src="<?php echo $path_js; ?>jquery-3.3.1.min.js"></script>

	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >
  <link rel="stylesheet" type="text/css" href="css/font.css">

	<script>
        function Mostrar() {
            document.getElementById("menu").style.display = "block";
            document.getElementById("cuerpo").style.marginLeft = "230px";
        }

        function Ocultar() {
            document.getElementById("menu").style.display = "none";
            document.getElementById("cuerpo").style.marginLeft = "0px";
        }

        function Mostrar_Ocultar() {
          var menu=document.getElementById("menu");

          if (menu.style.display=="none") {
            Mostrar();
          }else{
            Ocultar();
          }
        }

        function cambiar_img(imag){
          alert(imag);
          //var resultado_img=document.getElementById("picture_img_perfil");
          //resultado_img.innerHTML=" <img  class='img-perfil_agus' src='"+imag+"'  id='img_dinamic'>";
         // document.getElementById("img_dinamic").src=imag;
        }
        //MDDAL validar OBRA SOCIAL
        function Abrir_verif_obsocial() {
            document.getElementById("validar-obsocial").style.display = "block";
        }

        function Cerrar_verif_obsocial() {
            document.getElementById("validar-obsocial").style.display = "none";
        }

    </script>

</head>
<body>


 

<div class="container fondo_a">

  <?php include "menu.php"; ?>      
	    

    <section class="cuerpo" id="cuerpo">
    	<h2>

    		<a id="abrir" class="abrir-cerrar" href="javascript:void(0)" onclick="Mostrar_Ocultar()">
            	<div class="abrir-menu"><i class="fas fa-align-justify"></i></div>
         	</a>

         	Ajustes de Perfil

    		<img  class="logo-responsive" src="img/logo.png" alt="">
    	</h2>


      <div id="container-ejustes-perfil">
        <form  action="ajustes_perfil.php" method="POST" enctype="multipart/form-data" id="perfil_form">

           <div class="carga-foto"> 
            <div class="img-perfil" id="picture_img_perfil">
              <img  class="img-perfil_agus" src="img/photo_perfil/<?php echo($_SESSION["id_usuario"]) ?>.jpg" alt="" id="img_dinamic">   
            </div>
            
               <?php 
                      if ($_SESSION["nivel_usuario"]!='1') {
                        echo "<div class='verificar-ob'><a href='javascript:void(0)' onclick='Abrir_verif_obsocial(),Listar_ob_es_0($especialista)'><i class='fa fa-plus'>
                          </i> CONFIGURAR OB</a> </div>";
                      }
                       // echo Listar_ob_es_1($conn, $especialista);
                ?>
            
            <div class="content-input-img">
              <input class="up-img" name="archivo[]" type="file" id="auxilias" id="auxilias" >
            </div>
          </div>

          <div class="name">
            <label for="dni"></label>
            <input type="text" placeholder="DNI"id="dni_input" value="<?php echo($valores[9]) ?>" name="dni">
          </div>
          <div class="email">
            <label for="nacimiento"></label>
            <input type="date" id="nacimiento_input"  value="<?php echo($valores[10]) ?>"  name="fecha_nac" >
          </div>
          <div class="telephone">
            <label for="name"></label>
            <input type="text" placeholder="celular" id="celular_input" value="<?php echo($valores[6]) ?>" name="celular" >
          </div>
          <div class="subject">
            <label for="especialidad"></label>
              <?php 
                echo Listar_es_es($conn, $especialista);
               ?>
            </select>
          </div>
          <div class="sexo">
            <label for="sexo"></label>
            <input type="text" placeholder="Sexo" id="celular_input" value="<?php echo($valores[11]) ?>" name="sexo">
          </div>
          <div class="contraseña">
            <label for="name"></label>
            <input type="text" placeholder="contraseña"  id="contraseña_input" value="<?php echo($valores[7]) ?>" name="pass" >
          </div>

          <div class="submit">
            <input type="submit" value="GUARDAR" id="form_button" name="btn_guardar_e" />
          </div>

        </form><!-- // End form -->
      </div><!-- // End #container -->



      <div class="modal-validar-obsocial" id="validar-obsocial">
         <div id="validation-form">
          <div class="fieldset">
            <span href="javascript:void(0)" onclick="Cerrar_verif_obsocial()">X</span>
             <div class="title-table">
                Obras Sociales
              </div>
              <div class="table-sociales-container">
                <table>
                  <thead>
                    <tr>
                      <th>obras sociales agregadas</th>
                    </tr>
                  </thead>
                  <tbody>
                  <form action="" name="form_ajuste_perfil_02" >
                    <div id="form_ag_ob_es">
                      
                    </div>
                   
                    <input class="add-ob-ajuste" type="button" name="btn_agregar_ob" 
                    onclick="agregar_ob_es_l(<?php echo $especialista; ?>),Listar_ob_es_0(<?php echo $especialista; ?>)" 
                    value="agregar">
                  </form>

                  </tbody>
                </table>
                  <div id="mostrar_ob_espe">
                      
                  </div>
                    <?php 
                        //echo Listar_ob_es_2($conn, $especialista);
                    ?>


              </div>
          </div>
        </div>
    </div>





    </section>
<br>
<br><br>
<br>
<br>
<br>
<br>
<br>
<br>

    <br>
<br>


</div>



    <script>

    </script>
<script src="js/controlador_ajax.js"></script>

<scripst src="js/jquery.min.js"></scripst>

	
</body>
</html>