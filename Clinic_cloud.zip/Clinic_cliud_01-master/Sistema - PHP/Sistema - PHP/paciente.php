<?php 
$path_css="css/";
$path_js="";
 ?>

 <!-- CONECCION A LA BASE DE DATOS -->
  <?php 
include "funciones/conecxion.php";
include "funciones/f_paciente.php";

if (!$conn=conn_Star()) {
    header("location:error.php");
  }
  ?>
<!-- VALIDAR LOGEO -->
<?php 
  session_start();
  if (!isset($_SESSION["nombre"])){
     header("Location:logeo.php");
  }
 ?>

 <?php 
  if (isset($_GET['eliminar'])) {
    if(eliminar_paciente($conn,$_GET['eliminar'])==""){
      echo "ELIMINO";
    }else{
      echo "NO ELIMINO";
    }
  }
  ?>
 <!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Document</title>

        <?php include "funciones/header.html" ?>

    <link href="https://fonts.googleapis.com/css?family=Roboto:300" rel="stylesheet">


		<link rel="stylesheet" type="text/css" href="<?php echo $path_css;?>estilos_generales.css" />

    <link rel="stylesheet" type="text/css" href="<?php echo $path_css;?>estilos_paciente.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo $path_css;?>estilos_tabla.css" />

    <!-- Ventana historial clinico-->
    <link rel="stylesheet" type="text/css" href="<?php echo $path_css;?>estilos_clinico.css" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >
    <link rel="stylesheet" type="text/css" href="css/font.css">






	<script type="text/javascript" src="jquery-3.3.1.min.js"></script>
  


  <script type="text/javascript">
          $(document).ready(function(){
          $('ul.tabs li a:first').addClass('active');
          $('.secciones article').hide();
          $('.secciones article:first').show();

          $('ul.tabs li a').click(function(){
            $('ul.tabs li a').removeClass('active');
            $(this).addClass('active');
            $('.secciones article').hide();

            var activeTab = $(this).attr('href');
            $(activeTab).show();
            return false;
          });
        });
    </script>

	<script>
       function Mostrar() {
            document.getElementById("menu").style.display = "block";
            document.getElementById("cuerpo").style.marginLeft = "230px";
        }

        function Ocultar() {
            document.getElementById("menu").style.display = "none";
            document.getElementById("cuerpo").style.marginLeft = "0px";
        }

        function Mostrar_Ocultar() {
          var menu=document.getElementById("menu");

          if (menu.style.display=="none") {
            Mostrar();
          }else{
            Ocultar();
          }
        }
  </script>


    <script type="text/javascript">
      function openVentana(){
        $(".ventana").show();
      }
      function closeVentana(){
        $(".ventana").hide();
      }
  </script>

  <script type="text/javascript">
      function openVentana_menu(){
        $(".ventana-menu").show();
      }
      function closeVentana_menu(){
        $(".ventana-menu").hide();
      }
  </script>


  <script type="text/javascript">
    

  

    
      function acordion(){
        
        $(".box-body").hide();
        $(".box-header").click(function(event){
               var desplegable = $(this).next();
               $('.box-body').not(desplegable).slideUp('fast');
                desplegable.slideToggle('fast');
                event.preventDefault();
                });
      } 
  </script>

</head>
<body>


<div class="container">
<?php 
include "menu.php";
 ?>
	     

    <section class="cuerpo" id="cuerpo">
    	<h2> 
    		<a id="abrir" class="abrir-cerrar" href="javascript:void(0)" onclick="Mostrar_Ocultar()">
              <div class="abrir-menu"><i class="fas fa-align-justify"></i></div>
          </a>

         	Pacientes

    		<img  class="logo-responsive" src="img/logotipo.png" alt="">
    	</h2>




      <div class="wrap">

         <div class="form">
          <form action="" name="form_filtrar_pacientes">
            <div class="input-search">
                 <i id="search-paciente" class="fa fa-search" aria-hidden="true"></i>
                <input type="text" placeholder="Ej. 40678430" name="dni_filtrar" onkeyup="mostrar_pregunta(this.value)">
            </div>
          </form>
        </div>

        <div class="add">
         <!-- <a href="javascript:openVentana_add_paciente();" class="agregar">--> 
          <a href="agregar_paciente.php"><i class="fa fa-plus"></i> NUEVO PACIENTE</a>
        </div>

      </div>

    <div class="listado">
    <!--header tabla -->
      <div class="tabla">
        <div class="thead">
          <div class="nombre">
            <div>Dni / Nombre / Apellido</div>
          </div>
          <div class="info-general">
            <div>Celular</div>
            <div>Telefono</div>
            <div>OB. Social</div>
            <div>Nº Carnet</div>
            <div>Estado</div>
          </div>
        </div>

     
       <div id="listado_pacientes">
       <?php echo Listar_pacientes($conn); ?>
       </div>
     

       
     </div>
   </div>

  </section>


</div>











<div class="ventana-menu">
    <a class="btn-close-clinico" href="javascript:closeVentana_menu();"><i class="fa fa-times" aria-hidden="true"></i></a>

    <div class="wrap-menu">

        <div class="secciones" id="p_opciones">
          <a href="#" class="opcion-menu">
            <p>INICIAR CONSULTA</p>
          </a>
          <div class="opcion-menu">
            <p>VER EXPEDIENTE</p>
          </div>
          <a href="#" class="opcion-menu">
            <p>EDITAR PACIENTE</p>
          </a>
          <a href="#" class="opcion-menu ops-especial">
            <p>BORRAR PACIENTE</p>
          </a>
        </div>
      
    </div>
    
</div>





<div class="ventana"> 

  <a class="btn-close-clinico" href="javascript:closeVentana();"><i class="fa fa-times" aria-hidden="true"></i></a>


  <div class="wrap-clinico">
            <ul class="tabs">
                <li><a href="#tab1"><span class="fa fa-home"></span><span class="tab-text">Informacion</span></a></li>
                <li><a href="#tab2"><span class="fa fa-group"></span><span class="tab-text">Consultas</span></a></li>
                <li><a href="#tab3"><span class="fa fa-briefcase"></span><span class="tab-text">Estudios</span></a></li>
                <li><a href="#tab4"><span class="fa fa-bookmark"></span><span class="tab-text">Antecedentes</span></a></li>
            </ul>

            <div class="secciones">
                <article id="tab1">
                    <h1 class="title-clinico t1">Datos Personales</h1>

                    <form action="" class="form-historia" name="fomulario_paciente">
                        <div class="input-clinico">
                            <i class="far fa-user" aria-hidden="true"> <h5>Dni</h5> </i>
                            <input type="text" placeholder="Dni" name="dni" onchange="mostrar_preguntas('1')">
                         </div>

                        <div class="input-clinico">
                            <i class="far fa-user" aria-hidden="true"> <h5>Nombre</h5> </i>
                            <input type="text" placeholder="Nombre" name="nombre">
                        </div>

                        <div class="input-clinico">
                            <i class="far fa-user" aria-hidden="true"> <h5>Apellido</h5> </i>
                            <input type="text" placeholder="Apellido" name="apellido">
                        </div>

  <!--                  <div class="input-clinico">
                            <i class="far fa-user" aria-hidden="true"> <h5>Provincia</h5> </i>
                            <input type="text" placeholder="Provincia"  class="input-clinico-top" name="provincia">
                        </div>
  -->
                         <div class="input-clinico">
                            <i class="far fa-user" aria-hidden="true"> <h5>Direccion</h5> </i>
                            <input type="text" placeholder="Direccion"  class="input-clinico-top" name="direccion">
                        </div>

                         <div class="input-clinico">
                            <i class="far fa-user" aria-hidden="true"> <h5>Fech. Nac.</h5> </i>
                            <input type="text" placeholder="Fecha de Nacimiento"  class="input-clinico-top" name="fech_nacimiento">
                        </div>

                         <div class="input-clinico">
                            <i class="far fa-user" aria-hidden="true"> <h5>Telefono</h5> </i>
                            <input type="text" placeholder="Telefono" name="telefono">
                        </div>

                         <div class="input-clinico">
                            <i class="far fa-user" aria-hidden="true"> <h5>Celular</h5> </i>
                            <input type="text" placeholder="Celular" name="celular">
                        </div>

                         <div class="input-clinico">
                            <i class="far fa-user" aria-hidden="true"> <h5>Sexo</h5> </i>
                            <input type="text" placeholder="Sexo" name="sexo">
                        </div>


                         <h1 class="title-clinico t2">Datos Personales</h1>


                        <div class="input-clinico">
                            <i class="far fa-user" aria-hidden="true"> <h5>Obra Social</h5> </i>
                            <input type="text" placeholder="Obra Social" name="obra_social">
                        </div>

                         <div class="input-clinico">
                            <i class="far fa-user" aria-hidden="true"> <h5>N° Afiliado</h5> </i>
                            <input type="text" placeholder="Numero Afiliado"  class="input-clinico-top" name="n_afiliado">
                        </div>

                          <div class="input-clinico">
                            <i class="far fa-user" aria-hidden="true"> <h5>Estado</h5> </i>
                            <input type="text" placeholder="Estado"  class="input-clinico-top" name="estado">
                        </div>

                    </form>
                </article>
                <article id="tab2">
                    <h1 class="title-clinico ">Consultas</h1>

                    <div class="filtro-consulta">
                      <form action="">
                        <div class="input-clinico input-consultas">
                            <i class="far fa-user" aria-hidden="true"> <h5>Fecha Desde</h5> </i>
                            <input type="date" placeholder="Fecha Desde"  class="input-clinico-top">
                        </div>
                        <div class="input-clinico input-consultas">
                            <i class="far fa-user" aria-hidden="true"> <h5>Fecha Hasta</h5> </i>
                            <input type="date" placeholder="Fecha Hasta"  class="input-clinico-top">
                        </div>

                            <input type="submit" value="Filtrar"  class="input-clinico-submit">

                      </form>
                    </div>

                    <div class="box-card">
                        <div class="box-header">
                          <div class="fecha">
                            <p>17/07/2017</p>
                          </div>
                          <div class="especialista">
                            <p>Especialidad : Especialista</p>
                          </div>
                        </div>

                        <div class="box-body">
                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque sequi molestiae possimus adipisci dignissimos consectetur laboriosam, quidem, illum nobis. Facilis repellendus perspiciatis obcaecati soluta illo, voluptatem labore numquam, deleniti aliquid.</p>
                        </div>
                    </div>
                    <div id="res_historia">
                      
                    </div>


                </article>
                <article id="tab3">
                    <h1 class="title-clinico ">Estudios</h1>

                    <div class="filtro-consulta">
                      <form action="">
                        <div class="input-clinico input-consultas">
                            <i class="far fa-user" aria-hidden="true"> <h5>Fecha Desde</h5> </i>
                            <input type="date" placeholder="Fecha Desde"  class="input-clinico-top">
                        </div>
                        <div class="input-clinico input-consultas">
                            <i class="far fa-user" aria-hidden="true"> <h5>Fecha Hasta</h5> </i>
                            <input type="date" placeholder="Fecha Hasta"  class="input-clinico-top">
                        </div>

                            <input type="submit" value="Filtrar"  class="input-clinico-submit">

                      </form>
                    </div>

                    <div class="box-card">
                        <div class="box-header">
                          <div class="fecha">
                            <p>17/07/2017</p>
                          </div>
                          <div class="especialista">
                            <p>Especialidad : Especialista</p>
                          </div>
                        </div>

                        <div class="box-body">
                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque sequi molestiae possimus adipisci dignissimos consectetur laboriosam, quidem, illum nobis. Facilis repellendus perspiciatis obcaecati soluta illo, voluptatem labore numquam, deleniti aliquid.</p>           

                         <div class="input-estudio">
                            <input type="file" class="input-file-estudio">
                          </div>                   
                          
                        </div>
                    </div>

                    <div class="box-card">
                        <div class="box-header">
                          <div class="fecha">
                            <p>17/07/2017</p>
                          </div>
                          <div class="especialista">
                            <p>Especialidad : Especialista</p>
                          </div>
                        </div>

                        <div class="box-body">
                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque sequi molestiae possimus adipisci dignissimos consectetur laboriosam, quidem, illum nobis. Facilis repellendus perspiciatis obcaecati soluta illo, voluptatem labore numquam, deleniti aliquid.</p>

                          <div class="input-estudio">
                            <input type="file" class="input-file-estudio">
                          </div>
                          
                        </div>
                    </div>

                    <div class="box-card">
                        <div class="box-header">
                          <div class="fecha">
                            <p>17/07/2017</p>
                          </div>
                          <div class="especialista">
                            <p>Especialidad : Especialista</p>
                          </div>
                        </div>

                        <div class="box-body">
                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque sequi molestiae possimus adipisci dignissimos consectetur laboriosam, quidem, illum nobis. Facilis repellendus perspiciatis obcaecati soluta illo, voluptatem labore numquam, deleniti aliquid.</p>

                          <div class="input-estudio">
                            <input type="file" class="input-file-estudio">
                          </div>  
                          
                        </div>
                    </div>

                    <div class="box-card">
                        <div class="box-header">
                          <div class="fecha">
                            <p>17/07/2017</p>
                          </div>
                          <div class="especialista">
                            <p>Especialidad : Especialista</p>
                          </div>
                        </div>

                        <div class="box-body">
                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque sequi molestiae possimus adipisci dignissimos consectetur laboriosam, quidem, illum nobis. Facilis repellendus perspiciatis obcaecati soluta illo, voluptatem labore numquam, deleniti aliquid.</p>

                          <div class="input-estudio">
                            <input type="file" class="input-file-estudio">
                          </div>

                        </div>
                    </div>
                </article>
                <article id="tab4">
                    <h1 class="title-clinico ">Antecedentes</h1>
                    
                    <div class="box-card box-antecedente">

                        <div class="box-header header-antecedente">
                          <div class="ops-ant">
                            <i class="fa fa-bars" aria-hidden="true"></i>Familiares
                          </div>
                          <i class="fa fa-bars icon-antecedentes" aria-hidden="true"></i>
                        </div>

                        <div class="box-body body-antecedentes">
                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque sequi molestiae possimus adipisci dignissimos consectetur laboriosam, quidem, illum nobis. Facilis repellendus perspiciatis obcaecati soluta illo, voluptatem labore numquam, deleniti aliquid.</p>

                          <div class="input-estudio">
                            <input type="file" class="input-file-estudio">
                          </div>

                        </div>
                    </div>
                </article>
          </div>
</div>




 <script type="text/javascript">
         
         function borrar_paciente(id_pac){
            if(confirm("Seguro que desea Eleminar a este Usuario")){
              location.href ="paciente.php?eliminar="+id_pac;
            }
         } 
    </script>


<script src="js/controlador_ajax.js"></script>
<scripst src="js/jquery.min.js"></scripst>

	
</body>
</html>