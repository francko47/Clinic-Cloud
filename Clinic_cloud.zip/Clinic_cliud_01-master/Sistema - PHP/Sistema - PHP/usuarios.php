<?php 
$path_css="css/";
$path_js="";
 ?>

 <!-- CONECCION A LA BASE DE DATOS -->
  <?php 
include "funciones/conecxion.php";
include "funciones/f_usuarios.php";

if (!$conn=conn_Star()) {
    header("location:error.php");
  }
  ?>
<!-- VALIDAR LOGEO -->
<?php 
  session_start();
  if (!isset($_SESSION["nombre"])){
     header("Location:logeo.php");
  }
 ?>


<!-- AGREGAR -->
 <?php 
    if (isset($_POST["btn_AG_US"])) {
      $nombre=$_POST["nombre"];
      $apellido=$_POST["apellido"];
      $nivel_usuario=$_POST["tipo"];
      $dni=$_POST["dni"];
      $sexo=$_POST["sexo"];
      $pass=$_POST["pass"];
      $sql_a="INSERT INTO `c_c_santino_01`.`especialista` (`id_especialidad`, `id_obra_social`, `nombre`, `apellido`, `telefono`, `celular`, `pass`, `nivel_usuario`) VALUES ('2', '2', '$nombre', '$apellido', '1223434', '2243244', '$pass', '$nivel_usuario');";
      if(agregar($sql_a,$conn)){
       // header("Location:usuarios.php");
      }
    }

  ?>
<!-- MIDIFICAR -->
   <?php 
    if (isset($_POST["btn_M_US"])) {
      $nombre=$_POST["nombre"];
      $apellido=$_POST["apellido"];
      $nivel_usuario=$_POST["tipo"];
      $dni=$_POST["dni"];
      $sexo=$_POST["sexo"];
      $pass=$_POST["pass"];
      $id_usuario=$_POST["id_usuario"];

      
      $sql_a="UPDATE `c_c_santino_01`.`especialista` SET `nombre`='$nombre', `apellido`='$apellido', `nivel_usuario`='$nivel_usuario', `dni`='$dni', `sexo`='$sexo',`pass`='$pass' WHERE `id_especialista`='$id_usuario';";
      if(agregar($sql_a,$conn)){
       // header("Location:usuarios.php");
      }
    }

  ?>

  <?php 
  if (isset($_GET['eliminar'])) {
    if(eliminar_usuario($conn,$_GET['eliminar'])==""){
      echo "ELIMINO";
    }else{
      echo "NO ELIMINO";
    }
  }
  ?>
 <!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
        <?php include "funciones/header.html" ?>


    <link href="https://fonts.googleapis.com/css?family=Roboto:300" rel="stylesheet">

		
		<link rel="stylesheet" type="text/css" href="<?php echo $path_css;?>estilos_generales.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo $path_css;?>estilos_usuarios.css" />


	<script type="text/javascript" src="jquery-3.3.1.min.js"></script>

	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >
  <link rel="stylesheet" type="text/css" href="css/font.css">

	<script>
        function Mostrar() {
            document.getElementById("menu").style.display = "block";
            document.getElementById("cuerpo").style.marginLeft = "230px";
        }

        function Ocultar() {
            document.getElementById("menu").style.display = "none";
            document.getElementById("cuerpo").style.marginLeft = "0px";
        }

        function Mostrar_Ocultar() {
          var menu=document.getElementById("menu");

          if (menu.style.display=="none") {
            Mostrar();
          }else{
            Ocultar();
          }
        }


        //MDDAL AGREGAR USUARIOS
        function Abrir_usu() {
            document.getElementById("agregar-usuario").style.display = "block";
        }

        function Cerrar_usu() {
            document.getElementById("agregar-usuario").style.display = "none";
        }

         //MDDAL MODIFICAR USUARIOS
        function Abrir_M_usu() {
            document.getElementById("agregar-M-usuario").style.display = "block";
        }

        function Cerrar_M_usu() {
            document.getElementById("agregar-M-usuario").style.display = "none";
        }

    </script>

</head>
<body>


<div class="container">

  <?php include "menu.php"; ?>      
	      

    <section class="cuerpo" id="cuerpo">
    	<h2>

    		<a id="abrir" class="abrir-cerrar" href="javascript:void(0)" onclick="Mostrar_Ocultar()">
            	<div class="abrir-menu"><i class="fas fa-align-justify"></i></div>
         	</a>

         	Usuarios

    		<img  class="logo-responsive" src="img/logo.png" alt="">
    	</h2>


     
      <div class="add_user">
       <!-- <a href="javascript:openVentana_add_paciente();" class="agregar">--> 
        <a href="javascript:void(0)" onclick="Abrir_usu()"><i class="fa fa-plus"></i> NUEVO USUARIO</a>
      </div>



    <div id="main-container">

        <div class="title-table">
          Recepcionista
        </div>
      <div class="table-user-container">
        <table>
          <thead>
            <tr>
              <th>Estado</th><th>Nivel de usuario</th><th>Usuario</th><th>Contraseña</th><th>Modificar</th><th>Eliminar</th>
            </tr>
          </thead>

          
          <?php 
            echo Listar_Uusuarios($conn);
           ?>


<!--<tr>
            <td>Null</td><td>Roberto Carlos</td><td>Robert</td><td>1234</td><td><i class="fa fa-sync" aria-hidden="true"></i></td><td><i class="fa fa-trash" aria-hidden="true"></i></td>
          </tr>
          <tr>
            <td>Ok</td><td>Roberto Carlos</td><td>Robert</td><td>1234</td><td><i class="fa fa-sync" aria-hidden="true"></i></td><td><i class="fa fa-trash" aria-hidden="true"></i></td>
          </tr>
          <tr>
            <td>Ok</td><td>Roberto Carlos</td><td>Robert</td><td>1234</td><td><i class="fa fa-sync" aria-hidden="true"></i></td><td><i class="fa fa-trash" aria-hidden="true"></i></td>
          </tr>
          <tr>
            <td>Null</td><td>Roberto Carlos</td><td>Robert</td><td>1234</td><td><i class="fa fa-sync" aria-hidden="true"></i></td><td><i class="fa fa-trash" aria-hidden="true"></i></td>
          </tr>
          <tr>
            <td>Ok</td><td>Roberto Carlos</td><td>Robert</td><td>1234</td><td><i class="fa fa-sync" aria-hidden="true"></i></td><td><i class="fa fa-trash" aria-hidden="true"></i></td>
          </tr>

        -->
        </table>
      </div>
    </div>
 
    </section>




    <div class="modal-add-user" id="agregar-usuario">
         <div id="registration-form">
          <div class='fieldset'>
            <legend>Crear Usuario  <span href="javascript:void(0)" onclick="Cerrar_usu()">X</span></legend>
            <form action="usuarios.php" method="post" data-validate="parsley">
              <div class='row'>
                <label for='Dni'>Dni</label>
                <input type="text" placeholder="DNI" name='dni' id='dni' data-required="true" data-error-message="Ingrese DNI">
              </div>
              <div class='row'>
                <label for="Nombre">Nombre</label>
                <input type="text" placeholder="Nombre"  name='nombre' data-required="true" data-type="nombre" data-error-message="Ingrese Nombre">
              </div>
              <div class='row'>
                <label for="Apellido">Apellido</label>
                <input type="text" placeholder="Apellido" name='apellido' data-required="true" data-error-message="Ingrese Apellido">
              </div>
              <div class='row' >
                <label for="Sexo">Sexo</label>
                <select name="sexo">
                  <option value="H">Masculino</option>
                  <option value="M">Femenino</option>
                </select>
              </div>
              <div class='row'>
                <label for="Tipo">Tipo</label>
                <select name="tipo">
                  <option value="1">Recepcionista</option>
                  <option value="2">Especialista</option>
                  <option value="0">Administrador</option>
                </select>
              </div>

               <div class='row'>
                <label for="Nombre">Contraseña</label>
                <input type="password" placeholder="password"  name='pass' data-required="true" data-type="nombre" data-error-message="Ingrese Nombre">
              </div>
            

              <input type="submit" name="btn_AG_US" value="Registrar">
            </form>
          </div>
        </div>
    </div>


<!-- MODIFICAR USUARIO -->
 <div class="modal-add-user" id="agregar-M-usuario">
         <div id="registration-form">
          <div class='fieldset'>
            <legend>Crear Usuario  <span href="javascript:void(0)" onclick="Cerrar_M_usu()">X</span></legend>
            <form action="usuarios.php" method="post" data-validate="parsley" name="form_m_usuario">
                <input type="text" name='id_usuario'>

              <div class='row'>
                <label for='Dni'>Dni</label>
                <input type="text" placeholder="DNI" name='dni' id='dni' data-required="true" data-error-message="Ingrese DNI">
              </div>
              <div class='row'>
                <label for="Nombre">Nombre</label>
                <input type="text" placeholder="Nombre"  name='nombre' data-required="true" data-type="nombre" data-error-message="Ingrese Nombre">
              </div>
              <div class='row'>
                <label for="Apellido">Apellido</label>
                <input type="text" placeholder="Apellido" name='apellido' data-required="true" data-error-message="Ingrese Apellido">
              </div>
              <div class='row' >
                <label for="Sexo">Sexo</label>
                <select name="sexo" id="sexo_usuario">
                  <option value="H">Masculino</option>
                  <option value="M">Femenino</option>
                </select>
              </div>
              <div class='row'>
                <label for="Tipo">Tipo</label>
                <select name="tipo" id="tipo_usuario">
                  <option value="1">Recepcionista</option>
                  <option value="2">Especialista</option>
                  <option value="0">Administrador</option>
                </select>
              </div>

               <div class='row'>
                <label for="Nombre">Contraseña</label>
                <input type="text" placeholder="password"  name='pass' data-required="true" data-type="nombre" data-error-message="Ingrese Nombre">
              </div>
            

              <input type="submit" name="btn_M_US" value="Modificar">
            </form>
          </div>
        </div>
    </div>

</div>


 <script type="text/javascript">
         
         function borrar_usuario(id_usu){
            if(confirm("Seguro que desea Eleminar a este Usuario")){
              location.href ="usuarios.php?eliminar="+id_usu;
            }
         } 
    </script>

<script src="js/controlador_ajax.js"></script>

<scripst src="js/jquery.min.js"></scripst>

	
</body>
</html>