 <?php 
include "conecxion.php";


if (!$conn=conn_Star()) {
    header("location:error.php");
  }
  ?>
<?php 
  session_start();
  if (!isset($_SESSION["nombre"])){
     header("Location:logeo.php");
  }
 ?>

  <?php
 //DATO obra social
	if (isset($_GET["usuario"])) {

		$sql="SELECT id_especialista,dni,nombre,apellido,pass FROM c_c_santino_01.especialista WHERE id_especialista='".$_GET["usuario"]."';";

		if($resultado=seleccionar($sql,$conn)){
			while ($fila = mysqli_fetch_row($resultado)) {
				echo $fila[0].",";
				echo $fila[1].",";
				echo $fila[2].",";
				echo $fila[3].",";
				echo $fila[4].",";
				echo $fila[4].",";
			}


		}
	}


	if (isset($_GET["sexo"])) {

		$sql="SELECT sexo FROM c_c_santino_01.especialista WHERE id_especialista='".$_GET["sexo"]."';";
		$sexM="";
		$sexH="";
		if($resultado=seleccionar($sql,$conn)){
			while ($fila = mysqli_fetch_row($resultado)) {
				if ($fila[0]=="M") {
						$sexM="selected";
					}
				if ($fila[0]=="H") {
					$sexH="selected";
				}	
			}

			echo "<option value='H' ".$sexH.">Masculino</option>
                  <option value='M' ".$sexM.">Femenino</option>";
		}
	}


	if (isset($_GET["tipo"])) {

		$sql="SELECT nivel_usuario FROM c_c_santino_01.especialista WHERE id_especialista='".$_GET["tipo"]."';";
		if($resultado=seleccionar($sql,$conn)){
			while ($fila = mysqli_fetch_row($resultado)) {
				echo $fila[0];
				if ($fila[0]=="0"){
					echo "<option value='0' selected>administrador</option>";
					echo "<option value='1' >recepcionista</option>";
					echo "<option value='2' >especialista</option>";
				}
				if ($fila[0]=="1"){
					echo "<option value='0' >administrador</option>";
					echo "<option value='1' selected>recepcionista</option>";
					echo "<option value='2' >especialista</option>";
				}
				if ($fila[0]=="2"){
					echo "<option value='0' >administrador</option>";
					echo "<option value='1' >recepcionista</option>";
					echo "<option value='2' selected>especialista</option>";
				}
			}

                  
		}
	}

	
  
  ?>