<?php 

	function listar_especialista_t($conn){
		$res="";
		$sql="SELECT id_especialista,nombre,apellido FROM c_c_santino_01.especialista;";
		$res="<select id='esp' name='esp' onchange='listar_especialista_t(this.value)'>";
		if($resultado=seleccionar($sql,$conn)){
			while ($fila = mysqli_fetch_row($resultado)) {
                  $res= $res."<option value='".$fila[0]."'>".$fila[1].$fila[2]."</option>";
         	}  
		}
		$res=$res."</select>";
		return $res;
	}
 ?>
