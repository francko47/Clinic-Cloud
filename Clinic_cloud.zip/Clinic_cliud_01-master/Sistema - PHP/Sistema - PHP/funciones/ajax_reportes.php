  <?php 
include "conecxion.php";
include "f_R1.php";

if (!$conn=conn_Star()) {
    header("location:error.php");
  }
  ?>
<?php 
  session_start();
  if (!isset($_SESSION["nombre"])){
     header("Location:logeo.php");
  }
//____________________________________//
 ?>
<?php 
if (isset($_GET["R2"])) {
	$id=$_GET["R2"];
	$desde=$_GET["desde"];
	echo listar_RPQNA($conn,$id,$desde,"");
}
 ?>