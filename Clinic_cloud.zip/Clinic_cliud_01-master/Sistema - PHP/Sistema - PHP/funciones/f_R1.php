<?php 

	function lstar_espcialista($conn,$id){
		$sql="SELECT id_especialista,nombre,apellido FROM c_c_santino_01.especialista WHERE nivel_usuario!='2';";
		$res="<select class='select-filtro' name='registros' required>";
		if($resultado=seleccionar($sql,$conn)){
			while ($fila = mysqli_fetch_row($resultado)) {
				if ($fila[0]==$id) 
                  $res= $res."<option value=".$fila[0]." selected>".$fila[1]." ".$fila[2]."</option>";
         		else
                  $res= $res."<option value=".$fila[0].">".$fila[1]." ".$fila[2]."</option>";
         	}  
		}
        $res=$res."</select>";
		return $res;
	}

	function espcialista($conn,$id){
		$sql="SELECT id_especialista,nombre,apellido FROM c_c_santino_01.especialista WHERE nivel_usuario='2' and id_especialista='$id';";
		$res="<div class='btn-filtro display_none'>
				<select class='select-filtro' name='registros' >";
		if($resultado=seleccionar($sql,$conn)){
			while ($fila = mysqli_fetch_row($resultado)) {
                  $res= $res."<option value=".$fila[0].">".$fila[1]." ".$fila[2]."</option>";
         	}  
		}
        $res=$res."</select></div>";
		return $res;
	}

	function listar_RDPP($conn,$id){
		$sql="SELECT p.nombre,p.apellido,o.nombre_obra_soc,o.copago,t.pago,t.fecha,t.hora,t.min FROM c_c_santino_01.pacientes as p inner join c_c_santino_01.turno as t on p.id_paciente=t.id_paciente
 			inner join c_c_santino_01.ob_social_paciente as ob on p.id_paciente=ob.id_paciente
			inner join c_c_santino_01.obra_social as o on o.id_obra_social=ob.id_ob_social
 			WHERE t.fecha='2018-11-06' and t.id_especialista='$id';";
 			$res="";
			$_SESSION["reporte_sql"]=$sql;
		if($resultado=seleccionar($sql,$conn)){
			while ($fila = mysqli_fetch_row($resultado)) {
				$res=$res."<tr>";
                $res= $res." <td>".$fila[0]." ".$fila[1]."</td><td>".$fila[2]."</td><td>1234</td><td>$-</td><td>$-</td><td>$".$fila[4]."</td><td>$".$fila[3]."</td><td>$-</td><td>$-</td><td>$-</td>";
		        $res=$res."</tr>";
         	}  
		}
		return $res;
	}
//_____________________--------------------------------------___________________________________
//_____________________ REPORTES DE PACIENTES QUE NO ASISTIERON ___________________________________
//_____________________--------------------------------------___________________________________

	function listar_RPQNA($conn,$id,$desde,$hasta){
		$fecha="";
		if ($desde!="") {
			$fecha=$fecha." and date(t.fecha)>'$desde'";
		}
		if ($hasta!="") {
			$fecha=$fecha." and date(t.fecha)<'$hasta'";
		}
		$sql="SELECT p.nombre,p.apellido,p.dni,o.nombre_obra_soc,ob.nro_afiliado,t.fecha,t.hora,t.min,esobp.estado FROM c_c_santino_01.pacientes as p inner join c_c_santino_01.turno as t on p.id_paciente=t.id_paciente
 			inner join c_c_santino_01.ob_social_paciente as ob on p.id_paciente=ob.id_paciente
			inner join c_c_santino_01.obra_social as o on o.id_obra_social=ob.id_ob_social
            inner join c_c_santino_01.estados_ob_sociales as esobp on esobp.idestado=ob.estado
 			WHERE  t.estado_turno='2' and t.id_especialista='$id' ".$fecha.";";
 			$res="";

			$_SESSION["reporte_sql"]=$sql;
		if($resultado=seleccionar($sql,$conn)){
			while ($fila = mysqli_fetch_row($resultado)) {
				$res=$res."<tr>";
                $res= $res." <td>".$fila[0]." ".$fila[1]."</td><td>".$fila[2]."</td><td>".$fila[3]."</td><td>".$fila[4]."</td><td>".$fila[8]."</td>";
		        $res=$res."</tr>";
         	}  
		}
		return $res;
	}

 ?>
