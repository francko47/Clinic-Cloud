<?php 
include "conecxion.php";
include "f_turnos_redux.php";

if (!$conn=conn_Star()) {
    header("location:error.php");
  }
  ?>
<?php 
  session_start();
  if (!isset($_SESSION["nombre"])){
     header("Location:logeo.php");
  }
 ?><?php
 	

  ?><?php
 //LISTAR TURNOS
	if (isset($_GET["listar"])) {
		/////////////////////////////////////////////////////////////////////////////////////////
		if (isset($_GET["dia"])) {
 			$hoy = $_GET["dia"];
	 	}else{
	 		$hoy = date("Y-m-d");
	 	}
	 		$cont_res;
	 		
	 		$x_arr=0;
	 		$sql="SELECT p.*,o.nombre_obra_soc,ob_p.nro_afiliado,t.fecha,t.hora,t.min,t.estado_turno,t.id_paciente,copago,pago FROM c_c_santino_01.turno as t inner join c_c_santino_01.pacientes as p on t.id_paciente=p.id_paciente 
				inner join c_c_santino_01.ob_social_paciente as ob_p on ob_p.id_paciente=p.id_paciente inner join c_c_santino_01.obra_social as o on ob_p.id_ob_social=o.id_obra_social  WHERE fecha='$hoy' and t.id_especialista='".$_GET["listar"]."';";
			if($resultado=seleccionar($sql,$conn)){
				while ($fila = mysqli_fetch_row($resultado)) {
					$dni[$x_arr]=$fila[3];
					$nomyape[$x_arr]=strtoupper($fila[1])." ".strtoupper($fila[2]);
					$telefono[$x_arr]=$fila[4];
					$celular[$x_arr]=$fila[9];
					$ob_social[$x_arr]=$fila[10];
					$nro_afiliado[$x_arr]=$fila[11];
					$fecha[$x_arr]=$fila[12];
					$hora_arr[$x_arr]=$fila[13];
					$min_arr[$x_arr]=$fila[14];
					$estado_turno[$x_arr]=$fila[15];
					$id_paciente[$x_arr]=$fila[16];
					$copago[$x_arr]=$fila[17];
					$pago[$x_arr]=$fila[18];
					$x_arr++;
				}
			}
 		
		///////////////////////////////////////////////////////////////////////////////////////////
		echo "<div class='mes_seleccion'>
                  <form method='get' action='turnos_redux.html'>
                    <button type='button' name='dia_prev' class='dia_a_p'><i class='fas fa-angle-left'></i></button>
                    <input type='date' value='$hoy' name='año' id='año' class='fecha' onchange='listar_turno_redux_dia(this.value)'>
                    <button type='button' name='dia_prox'><i class='fas fa-angle-right'></i></button>
                  </form>
              </div>
              <table>
              <thead>

              <tr>
                <th></th><th>DNI</th><th>Nombre y apellido</th><th>Telefono</th><th>Celular</th><th>Obra social</th><th>N°Carnet</th><th>Coopago</th><th>Monto</th><th>Estado del Turno</th><th>Nuevo turno</th>
              </tr>
            </thead>";


            $duracion;
		$sql="SELECT horas_de_atencion FROM c_c_santino_01.especialista WHERE id_especialista='".$_GET["listar"]."';";
		if($resultado=seleccionar($sql,$conn)){
			while ($fila = mysqli_fetch_row($resultado)) {
				$duracion=$fila[0];
			}
		}
			$togle=2;
			$z=0;

		for ($i=8; $i<=19 ; $i++) { 
			$x=0;
			$dni_dom="";
			$nomyape_dom="";
			$telefono_dom="";
			$celular_dom="";
			$ob_social_dom="";
			$nro_afiliado_dom="";
			$fecha_dom="";
			$hora_arr_dom="";
			$min_arr_dom="";
			$estado_turno_dom="";
			$id_paciente_dom="";
			$copago_dom="";
			$pago_dom="";
			$btn_turno_1="re";
			$btn_turno_2="";
			///////////////////////////////////////////////////////////////////
			$sql_e="SELECT * FROM c_c_santino_01.estado_turno;";
			if($resultado_e=seleccionar($sql_e,$conn)){
				while ($fila_e = mysqli_fetch_row($resultado_e)) {
						$estado_turno_dom.=" <option value='".$fila_e[0]."'>".$fila_e[1]."</option>";
				}
			}
			$btn_turno_1="guardar";
			$btn_turno_2="ag_turno_redux(".$z.")";
			for ($n=0; $n<=$x_arr-1; $n++) { 
				//$btn_turno_1=$min_arr[$n]."  ".$x;
				if($i==$hora_arr[$n] && $x==$min_arr[$n]){
					$dni_dom=$dni[$n];
					$nomyape_dom=$nomyape[$n];
					$telefono_dom=$telefono[$n];
					$celular_dom=$celular[$n];
					$ob_social_dom=$ob_social[$n];
					$nro_afiliado_dom=$nro_afiliado[$n];
					$fecha_dom=$fecha[$n];
					$hora_arr_dom=$hora_arr[$n];
					$min_arr_dom=$min_arr[$n];
					$copago_dom=$copago[$n];
					$pago_dom=$pago[$n];
					$estado_turno_dom="";
					$id_paciente_dom=$id_paciente[$n];
					if ($_SESSION["nivel_usuario"]!=1) {
						$btn_turno_1="consultar";
						$btn_turno_2="ir_turno_redux(".$id_paciente_dom.")";
					}
					$sql_e="SELECT * FROM c_c_santino_01.estado_turno;";
						if($resultado_e=seleccionar($sql_e,$conn)){
							while ($fila_e = mysqli_fetch_row($resultado_e)) {
								if($estado_turno[$n]==$fila_e[0]){
									
									$estado_turno_dom.=" <option value='".$fila_e[0]."' selected>".$fila_e[1]."este</option>";
								}else{
									$estado_turno_dom.=" <option value='".$fila_e[0]."'>".$fila_e[1]."</option>";
								}				
							}
						}

				}
				//echo "<hr>".$hora_arr[$n]."<hr>";

			}
			/////////////////////////////////////////////////////////////////////
			echo "<form method='GET' action='' name='form_turnos_redux_".$z."'><tr><label id='control_columna' onclick='control_columna()' class='selecciona_columna'>
		            
		              <td class='turnos_horas'>".$i.":00</td>
		                <input type='hidden' id='id_".$z."'>
				        <input type='hidden' id='hs_".$z."' value='".$i."'>
				        <input type='hidden' id='min_".$z."' value='".$x."'>
		              <td><input type='text' id='dni_".$z."' value='".$dni_dom."' onkeyup='buscar_paciente_t_reduxs(this.value,".$z.")'
		             		style='text-transform:uppercase;' ></td>
		              <td><input type='text' id='nombre_".$z."' disabled value='".$nomyape_dom."' 
		              		style='text-transform:uppercase;'></td>
		              <td><input type='text' id='telefono_".$z."'  value='".$telefono_dom."' 
		              		style='text-transform:uppercase;'></td>
		              <td><input type='text' id='Celular_".$z."'  value='".$celular_dom."'  onclick='control_columna($z)' 
		              		style='text-transform:uppercase;'></td>
		              <td><input type='text' id='obra_social_".$z."'  value='".$ob_social_dom."' 
		              		style='text-transform:uppercase;'></td>
		              <td><input type='text' id='n_carnet_".$z."'  value='".$nro_afiliado_dom."' 
		              		style='text-transform:uppercase;'></td>
		              <td><input type='text' id='coopago_".$z."'  value='".$copago_dom."' 
		              		style='text-transform:uppercase;'></td>
					  <td><input type='text' id='monto_".$z."'  value='".$pago_dom."' 
					  		style='text-transform:uppercase;' 
					  		onkeyup='cambiar_pago(this.value,$id_paciente_dom,$i,$x)'></td>
		              <td>
		              <select class='estado_t' name='estado_t' id='estado_t_".$z."' ";

							echo "	onchange='cambiar_estado_turno(this.value,$id_paciente_dom,$i,$x)'>";
							echo $estado_turno_dom."
							</select>
		              </td>
		              <td><input type='button' value='".$btn_turno_1."' class='agregar_turno' name='nuevo_turno' onclick='".$btn_turno_2."'></td>
		            
		            </label>
		            </tr> </form>";
		            $togle+=2;
		            $z++;
		            $x+=$duracion;
			while ($x<=60) {
				
				if ($x!=60) {
						$dni_dom="";$nomyape_dom="";$telefono_dom="";$celular_dom="";$ob_social_dom="";
						$nro_afiliado_dom="";$fecha_dom="";$hora_arr_dom="";$min_arr_dom="";$estado_turno_dom="";
						$id_paciente_dom="";
						$copago_dom="";
						$pago_dom="";
			///////////////////////////////////////////////////////////////////
						$sql_e="SELECT * FROM c_c_santino_01.estado_turno;";
									if($resultado_e=seleccionar($sql_e,$conn)){
										while ($fila_e = mysqli_fetch_row($resultado_e)) {
											
												$estado_turno_dom.=" <option value='".$fila_e[0]."'>".$fila_e[1]."</option>";
										}
									}
						$btn_turno_1="guardar";
						$btn_turno_2="ag_turno_redux(".$z.")";
						for ($n=0; $n<=$x_arr-1; $n++) { 
							if($i==$hora_arr[$n] && $x==$min_arr[$n]){
								$dni_dom=$dni[$n];
								$nomyape_dom=$nomyape[$n];
								$telefono_dom=$telefono[$n];
								$celular_dom=$celular[$n];
								$ob_social_dom=$ob_social[$n];
								$nro_afiliado_dom=$nro_afiliado[$n];
								$fecha_dom=$fecha[$n];
								$hora_arr_dom=$hora_arr[$n];
								$min_arr_dom=$min_arr[$n];
								$copago_dom=$copago[$n];
								$pago_dom=$pago[$n];
								$estado_turno_dom="";
								$id_paciente_dom=$id_paciente[$n];
								if ($_SESSION["nivel_usuario"]!=1) {
									$btn_turno_1="consultar";
									$btn_turno_2="ir_turno_redux(".$id_paciente_dom.")";

								}
								
								$sql_e="SELECT * FROM c_c_santino_01.estado_turno;";
									if($resultado_e=seleccionar($sql_e,$conn)){
										while ($fila_e = mysqli_fetch_row($resultado_e)) {
											if($estado_turno[$n]==$fila_e[0]){
												$estado_turno_dom.=" <option value='".$fila_e[0]."' selected>".$fila_e[1]."</option>";
											}else{
												$estado_turno_dom.=" <option value='".$fila_e[0]."'>".$fila_e[1]."</option>";
											}				
										}
									}
							}
						}
			

						echo "<form method='GET' action='' id='form_turnos_redux_".$z."'><tr>
				             <td class='turnos_minutos'>:".$x."</td>
				             <input type='hidden' id='id_".$z."'>
				             <input type='hidden' id='hs_".$z."' value='".$i."'>
				             <input type='hidden' id='min_".$z."' value='".$x."'>
				             <td><input type='text' id='dni_".$z."' value='".$dni_dom."' onkeyup='buscar_paciente_t_reduxs(this.value,".$z.")'></td>
							<td><input type='text' id='nombre_".$z."' disabled value='".$nomyape_dom."'></td>
							<td><input type='text' id='telefono_".$z."'  value='".$telefono_dom."'></td>
							<td><input type='text' id='Celular_".$z."'  value='".$celular_dom."'  onclick='control_columna($z)'></td>
							<td><input type='text' id='obra_social_".$z."'  value='".$ob_social_dom."'></td>
							<td><input type='text' id='n_carnet_".$z."'  value='".$nro_afiliado_dom."'></td>
							<td><input type='text' id='coopago_".$z."'  value='".$copago_dom."'></td>
							<td><input type='text' id='monto_".$z."'  value='".$pago_dom."' 
					  		style='text-transform:uppercase;' 
					  		onkeyup='cambiar_pago(this.value,$id_paciente_dom,$i,$x)'></td>
		              		<td>
							<select class='estado_t' name='estado_t' id='estado_t_".$z."' ";

							echo "onchange='cambiar_estado_turno(this.value,$id_paciente_dom,$i,$x)'>";
							echo $estado_turno_dom."
							</select>
							</td>
				             
				             <td><input type='button' value='".$btn_turno_1."' class='agregar_turno' name='nuevo_turno' onclick='".$btn_turno_2."'></td>
			             
		            </tr></form>";
		            $togle+=2;
		            $z++;

				}
		            $x+=$duracion;
			}
		}

					
            echo "</table>";
		/*if($resultado=seleccionar($sql,$conn)){
			while ($fila = mysqli_fetch_row($resultado)) {
			}
		}*/
	}
?><?php 

if (isset($_GET["buscar"])) {
	$res="";
	$dni=$_GET["buscar"];
	$sql="SELECT nombre,apellido,telefono,nombre_obra_soc,nro_afiliado,p.id_paciente,copago FROM c_c_santino_01.pacientes as p left join c_c_santino_01.ob_social_paciente as ob on p.id_paciente=ob.id_paciente left join c_c_santino_01.obra_social as o on o.id_obra_social=ob.id_ob_social  WHERE dni='$dni';";
		if($resultado=seleccionar($sql,$conn)){
			while ($fila = mysqli_fetch_row($resultado)) {
		        echo $fila[0]." ".$fila[1].","; 
		        echo $fila[5].",";      
		        echo $fila[2].",";      
		        echo $fila[3].",";      
		        echo $fila[4].",";      
		        echo $fila[6].",";      
		        echo $fila[5].",";      
      }
		}
		//echo $res;
}
 ?><?php 

if (isset($_GET["agregar"])) {
	$res="";
	$id_paciente=$_GET["agregar"];
	$especialista=$_GET["esp"];
	$hora=$_GET["hs"];
	$min=$_GET["min"];
	$fecha=$_GET["fecha"];
//	$hora=$hora.":".$min;
	$sql="INSERT INTO `c_c_santino_01`.`turno` (`id_paciente`, `id_especialista`, `fecha`, `hora`, `estado_turno`,`min`) VALUES ('$id_paciente', '$especialista', '$fecha', '$hora', '1','$min');
";
/*echo "<br>".$sql."<br>";
	echo "id_paciente: ".$_GET["agregar"];
	echo "especialista: ".$_GET["esp"];
	echo "hora: ".$_GET["hs"];
	echo "min: ".$_GET["min"];
*/		if(agregar($sql,$conn)){
			echo "true";
		}else{
			echo "false";
		}
		//echo $res;
}
 ?><?php 
	if (isset($_GET["estado_turno"])) {
		$estado=$_GET["estado_turno"];
		$es=$_GET["esp"];
		$fecha=$_GET["fecha"];
		$pac=$_GET["paci"];
		$hs=$_GET["hs"];
		$min=$_GET["min"];
		/*echo "<hr>estado:".$estado;
		echo "<hr>es:".$es;
		echo "<hr>fecha:".$fecha;
		echo "<hr>pac:".$pac;
		echo "<hr>hs:".$hs;
		echo "<hr>min:".$min;
	*/	$sql="UPDATE `c_c_santino_01`.`turno` SET `estado_turno`='$estado' WHERE `id_paciente`='$pac' and`id_especialista`='$es' and`fecha`='$fecha' and`hora`='$hs' and`min`='$min';";
		if(agregar($sql,$conn)){
			echo "actualizo correctamente";
		}else{
			echo "no se actualizo";
		}
		
	}

  ?>
  <?php 
	if (isset($_GET["cambiar_pago"])) {
		$pago=$_GET["cambiar_pago"];
		$es=$_GET["esp"];
		$fecha=$_GET["fecha"];
		$pac=$_GET["paci"];
		$hs=$_GET["hs"];
		$min=$_GET["min"];
		/*echo "<hr>estado:".$estado;
		echo "<hr>es:".$es;
		echo "<hr>fecha:".$fecha;
		echo "<hr>pac:".$pac;
		echo "<hr>hs:".$hs;
		echo "<hr>min:".$min;
	*/	

		$sql="UPDATE `c_c_santino_01`.`turno` SET `pago` = '$pago' WHERE (`id_paciente` = '$pac') and (`id_especialista` = '$es') and (`fecha` = '$fecha') and (`hora` = '$hs') and (`min` = '$min');";
		if(agregar($sql,$conn)){
			echo "actualizo correctamente";
		}else{
			echo "no se actualizo";
		}
		
	}

  ?>