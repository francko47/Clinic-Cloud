<?php 

	function Listar_es_es($conn,$id){
		$res="";
		$es_espe="";
		if ($id!==" ") {
			$sql="SELECT id_especialidad FROM c_c_santino_01.especialista WHERE id_especialista='".$id."'; ";
			if($resultado=seleccionar($sql,$conn)){ 
				while ($fila = mysqli_fetch_row($resultado))			
					$es_espe=$fila[0];
			}
		}
		$sql="SELECT * FROM c_c_santino_01.especialidad;";
		if($resultado=seleccionar($sql,$conn)){
			$url_agrefar_pas="";
			$res=" <select id='especialidad_input' name='especialidad'>";
			while ($fila = mysqli_fetch_row($resultado)) {
				if ($es_espe==$fila[0])
					$res=$res."<option class='ops-espe' value='".$fila[0]."' selected>".$fila[1]."</option>";
				else
					$res=$res."<option class='ops-espe' value='".$fila[0]."'>".$fila[1]."</option>";
         	}
			$res=$res."</select>";

		}
		
		return $res;
	}


	function Listar_ob_es_1($conn,$id){
		$res="";
		$es_ob="";
		
			$sql="SELECT id_obra_social,id_especialista,ob.nombre_obra_soc FROM obra_social as ob left join ob_sociales_especialista as ob_e on ob.id_obra_social=ob_e.id_ob_sociales WHERE id_especialista='$id' or id_especialista is null; ";

				if($resultado=seleccionar($sql,$conn)){
					$res="<select name='especialidad'>";
					while ($fila = mysqli_fetch_row($resultado)) {
						if ($fila[1]!=null) {
							$res=$res."<option value='".$fila[0]."'>".$fila[2]."</option>";
						}
		         	}
					$res=$res."</select>";
				}
		
		return $res;
	}

	function Listar_ob_es_2($conn,$id){
		$res="";
		$es_ob="";
		
			$sql="SELECT id_obra_social,id_especialista,ob.nombre_obra_soc FROM obra_social as ob left join ob_sociales_especialista as ob_e on ob.id_obra_social=ob_e.id_ob_sociales WHERE id_especialista='$id' or id_especialista is null; ";

				if($resultado=seleccionar($sql,$conn)){
					$res="<table>";
					while ($fila = mysqli_fetch_row($resultado)) {
						if ($fila[1]==null) {
							$res=$res."<tr>
					                     <td>".$fila[2]."</td>
					                     <td><a href='javaScrip:' >elimina<a/></td>
					                   </tr>";
						}
		         	}
					$res=$res."</table>";
				}
		
		return $res;
	}

	function cargar_datos($conn,$id){
		$res;
			$sql="SELECT * FROM c_c_santino_01.especialista;";
				if($resultado=seleccionar($sql,$conn)){
					
					if ($fila = mysqli_fetch_row($resultado)) {
						for ($i=0; $i <=count($fila)-1 ; $i++)
							$res[$i]=$fila[$i];	
		         	}
				}
		
		return $res;
	}


	function modificar_datos($conn,$id,$dni,$fecha_nac,$sexo,$celular,$pass,$especialidad){
		
		$sql="UPDATE `c_c_santino_01`.`especialista` SET `id_especialidad`='$especialidad', `celular`='$celular', `pass`='$pass', `dni`='$dni', `fecha_nacimiento_es`='$fecha_nac', `sexo`='$sexo' WHERE `id_especialista`='$id';";

		return agregar($sql,$conn);
		
	}
	function modificar_foto($conn,$id){
		
		$sql="UPDATE `c_c_santino_01`.`especialista` SET  `foto`='".$id.".jpg' WHERE `id_especialista`='$id';";

		return agregar($sql,$conn);
		
	}

                   ?>
                 