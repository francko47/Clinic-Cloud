<?php 



function Listar_Obsociales($conn){
		$res="";
		$sql="SELECT ob.*,estado_ob_Social FROM c_c_santino_01.obra_social as ob left join c_c_santino_01.estado_ob_sociales as es on ob.estado=es.id_estado_ob_sociales;";
		if($resultado=seleccionar($sql,$conn)){
			
			while ($fila = mysqli_fetch_row($resultado)) {
				$res=$res."
						   	<tr>
					            <td>".$fila[0]."</td><td>".$fila[4]."</td><td>".$fila[1]."</td><td>".$fila[2]."</td><td><i class='fa fa-sync' aria-hidden='true'  onclick='Abrir_M_obsocial(),mostrar_datos(".$fila[0]."),estado_ob_social_m(".$fila[0].")'></i></td>
					          </tr>

						   ";
				
         	}  
		}
		
		return $res;
	}


	function Listar_estados_ObSo($conn){
		$res="";
		$sql="SELECT * FROM c_c_santino_01.estado_ob_sociales;";
		if($resultado=seleccionar($sql,$conn)){
				$res=$res."<select name='estado'>";

			while ($fila = mysqli_fetch_row($resultado)) {
				$res=$res."<option value='".$fila[0]."'>".$fila[1]."</option>";
         	}  
				$res=$res."</select>";
		}
		
		return $res;
	}
 ?>