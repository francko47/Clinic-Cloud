<!-- CONECCION A LA BASE DE DATOS -->
  <?php 
include "conecxion.php";
include "f_paciente.php";

if (!$conn=conn_Star()) {
    header("location:error.php");
  }
  ?>
<!-- VALIDAR LOGEO -->
<?php 
  session_start();
  if (!isset($_SESSION["nombre"])){
     header("Location:logeo.php");
  }
 ?>


<?php 


    if (isset($_GET["btnNewPaciente"])) {
       $dni=$_GET["dni"];
      $nombre=$_GET["nombre"];
      $apellido=$_GET["apellido"];
      $fecha_nacimiento=$_GET["fecha_nacimiento"];
      $telefono=$_GET["telefono"];
      $celular=$_GET["celular"];
      $sexo=$_GET["sexo"];
      //FAMILIARES
      $nombre_tutor=$_GET["nombre_tutor"];
      $apellido_tutor=$_GET["apellido_tutor"];
      $dni_tutor=$_GET["dni_tutor"];
      //DATOS DEMOGRFICOS
      $direccion=$_GET["direccion"];
      $localidad=$_GET["localidad"];
      //OBRA SOCIAL
      $obra_Social=$_GET["obraSocial"];
      $n_afiliado=$_GET["n_afiliado"];
      $estado=$_GET["estado"];

  
      $sql_u="UPDATE `c_c_santino_01`.`pacientes` SET `nombre`='".$nombre."', `apellido`='".$apellido."', `telefono`='".$telefono."'  , `fech_nacimiento`='".$fecha_nacimiento."', `sexo`='".$sexo."', `celular`='".$celular."', `direccion`='".$direccion."', `localidad`='".$localidad."' WHERE `id_paciente`='".$_GET['id_paciente']."';";
    echo $sql_u;
      if(agregar($sql_u,$conn)){
        //header("location:../paciente.php");
      }else{
        //error
      }
      //FAMILIARES
      $sql_f="SELECT * FROM c_c_santino_01.familiares WHERE `id_paciente`='".$_GET['id_paciente']."';";
      if($res=seleccionar($sql_f,$conn)){ 
         $sql_f="UPDATE `c_c_santino_01`.`familiares` SET `nombre_tutor`='$nombre_tutor', `apellido_tutor`='$apellido_tutor', `dni_tutor`='$dni_tutor' WHERE `id_paciente`='".$_GET['id_paciente']."';";
          agregar($sql_f,$conn);  
      }else{
         $sql_f="INSERT INTO `c_c_santino_01`.`familiares` (`id_paciente`, `nombre_tutor`, `apellido_tutor`, `dni_tutor`) VALUES ('".$_GET['id_paciente']."', '$nombre_tutor', '$apellido_tutor', '$dni_tutor');";
          agregar($sql_f,$conn) ; 
      }

      //OBRA SOCIAL
       $sql_ob="SELECT * FROM c_c_santino_01.ob_social_paciente WHERE `id_paciente`='".$_GET['id_paciente']."';";
      if($res=seleccionar($sql_ob,$conn)){
        $sql_ob="UPDATE `c_c_santino_01`.`ob_social_paciente` SET `id_ob_social`='$obra_Social', `nro_afiliado`='$n_afiliado', `estado`='$estado' WHERE `id_paciente`='".$_GET['id_paciente']."';";
         agregar($sql_ob,$conn);

      }else{
         $sql_ob="INSERT INTO `c_c_santino_01`.`ob_social_paciente` (`id_ob_social`, `id_paciente`, `nro_afiliado`, `estado`) VALUES ('$obra_Social', '".$_GET['id_paciente']."', '$n_afiliado', '$estado');";
         agregar($sql_ob,$conn);

      }

      echo $sql_ob;
     header("location:../paciente.php");
    }

 ?>
