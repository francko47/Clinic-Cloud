<?php 
	function conn_Star(){
		$servidor="127.0.0.1:3306";//"localhost"
		$base="c_c_santino_01";//""
		$user="agus";//""
		$pass="agustin123456789";//""
		$conn = mysqli_connect($servidor, $user, $pass);
		if (!mysqli_connect_errno()){
			mysqli_select_db($conn,$base);
			return ($conn);
		}else{
			return false;
		}
	}

	function conn_Close($conn){
		mysql_close($conn);
		return true;
	}

/*<div class='info-lista'>
			                  <div class='info-header'>
			                    <div class='nombre-info'>".$fila[3]."  |  ".$fila[5]." <i class='fa fa-caret-down' aria-hidden='true'></i></div>
			                  </div>
			                  <div class='info-body'>

			                    <p class='detalles-info'>Especialista: ".$fila[6]." ".$fila[7]."</p>
			                    <p class='detalles-info'>Especialidad: ".$fila[8]."</p>
			                    <br>
			                    		".$fila[4]."
			                  </div>
			                </div>
*/	function get_select($atributos,$tablas,$condicion,$conn){

		$sql="SELECT ".$atributos." FROM ".$tablas." WHERE ".$condicion.";";
		if($result=mysqli_query($conn,$sql)){

			if (mysqli_num_rows($result)>0) {
				return $result;
			}else{
				return false;
			}
			}else{
				return false;
			}
	}

	function validar_usuario($user,$pass,$conn){
		$sql1="SELECT id_especialista,nombre,apellido,espe.id_especialidad,especialidad,esp.nivel_usuario FROM (especialista as esp inner join especialidad as espe on esp.id_especialidad=espe.id_especialidad) inner join nivel_usuario as nivel on nivel.id_nivel_usuario=esp.nivel_usuario WHERE nombre='$user' and pass='$pass';";
		$sql="SELECT * FROM c_c_santino_01.especialista WHERE nombre='$user' and pass='$pass';";

		$result=mysqli_query($conn,$sql1);
		if (mysqli_num_rows($result)>0) {
				return $result;
		}else{
			return false;
		}
		
	}

	function seleccionar($sql,$conn){


		if($result=mysqli_query($conn,$sql)){
			if (mysqli_num_rows($result)>0) {
					return $result;
			}else{
					return false;
			}
		}else{
			return false;
		}
	}

	

	function agregar($sql,$conn){

		if (mysqli_query($conn,$sql)) {
			return true;
		}else{
			return false;
		}
	}

	function agregar1($sql,$conn){

		if ($res=mysqli_query($conn,$sql)) {
			return $res;
		}else{
			return $res;
		}
	}

	function agregar_2($sql,$conn){

			if (mysqli_query($conn,$sql)) {
				return mysqli_insert_id($conn);
			}else{
				return false;
			}
	}

/*  while ($fila = mysqli_fetch_row($resultado)) {
                  echo "<option value=".$fila[0].">".$fila[1]."</option>";
                }   */

 
    function eliminar_paciente($conn,$id){
    	$res="";
    	$sql="DELETE FROM `c_c_santino_01`.`pacientes` WHERE `id_paciente`='$id';";
    	if(!agregar($sql,$conn)){
    		$res+="Error al Eliminar paciente;";
    	}
    	$sql="DELETE FROM `c_c_santino_01`.`familiares` WHERE `id_paciente`='$id';";
    	if(!agregar($sql,$conn)){
    		$res+="Error al Eliminar datos Familiares del paciente;";
    	}
//    	$sql="DELETE FROM `c_c_santino_01`.`consultas` WHERE `id_consulta`='12';";
    		return $res;
    }

 ?>

