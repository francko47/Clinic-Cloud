<?php 



function Listar_Uusuarios($conn){
		$res="";
		$sql="SELECT e.id_especialista,nl.nivel_usuario,nombre,pass FROM c_c_santino_01.especialista as e inner join c_c_santino_01.nivel_usuario as nl on e.nivel_usuario=nl.id_nivel_usuario;";
		if($resultado=seleccionar($sql,$conn)){
			
			while ($fila = mysqli_fetch_row($resultado)) {
				$res=$res."<tr>
								<td>Ok</td><td>".$fila[1]."</td><td>".$fila[2]."</td><td>".$fila[3]."</td><td><i class='fa fa-sync' aria-hidden='true' onclick='usuario_modificar_0(".$fila[0].")'></i></td><td><i class='fa fa-trash' aria-hidden='true' onclick='borrar_usuario(".$fila[0].")'></i></td>
						   </tr>";
				
         	}  
		}
		
		return $res;
	}

	function eliminar_usuario($conn,$id){

		$sql="DELETE FROM `c_c_santino_01`.`especialista` WHERE `id_especialista`='$id';";
		if(agregar($sql,$conn)){
			return true;
		}else{
			return false;			
		}
		
	}
 ?> 