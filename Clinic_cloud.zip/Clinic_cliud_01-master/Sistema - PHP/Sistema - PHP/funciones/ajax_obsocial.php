 <?php 
include "conecxion.php";


if (!$conn=conn_Star()) {
    header("location:error.php");
  }
  ?>
<?php 
  session_start();
  if (!isset($_SESSION["nombre"])){
     header("Location:logeo.php");
  }
 ?>

  <?php
 //DATO obra social
	if (isset($_GET["obsocial"])) {

		$sql="SELECT * FROM c_c_santino_01.obra_social WHERE id_obra_social='".$_GET["obsocial"]."';";

		if($resultado=seleccionar($sql,$conn)){
			while ($fila = mysqli_fetch_row($resultado)) {
				echo $fila[0].",";
				echo $fila[1].",";
				echo $fila[2].",";
			}


		}
	}

//ESTADOS OB SOCIALES
	if (isset($_GET["estado"])) {
		$estado="";
		$sql="SELECT ob.* FROM c_c_santino_01.obra_social as ob  where id_obra_social='".$_GET["estado"]."';";
		if($resultado=seleccionar($sql,$conn)){
			if ($fila = mysqli_fetch_row($resultado)) {
				$estado=$fila[3];
				$sql="SELECT * FROM c_c_santino_01.estado_ob_sociales;";
				if($resultado=seleccionar($sql,$conn)){
					while ($fila = mysqli_fetch_row($resultado)) {
						if($estado==$fila[0]){
							echo "<option value='".$fila[0]."' selected>".$fila[1]."</option>";
						}else{
							echo "<option value='".$fila[0]."'>".$fila[1]."</option>";
						}
					}
			    }
			}
		}
	}

	
  
  ?>