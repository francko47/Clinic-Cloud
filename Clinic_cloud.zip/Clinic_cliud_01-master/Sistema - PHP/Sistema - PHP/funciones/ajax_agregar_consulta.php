
  <?php 
include "conecxion.php";
include "f_paciente.php";

if (!$conn=conn_Star()) {
    header("location:error.php");
  }
  ?>
<?php 
  session_start();
  if (!isset($_SESSION["nombre"])){
     header("Location:logeo.php");
  }
 ?>

  <?php 

	if (isset($_GET["id_pacientes"])) {


		$sql="SELECT c.*,e.apellido,e.nombre,es.especialidad FROM c_c_santino_01.pacientes as p inner join consultas as c on p.id_paciente=c.id_paciente  inner join especialista as e on c.id_especialista=e.id_especialista inner join especialidad as es on e.id_especialidad=es.id_especialidad WHERE p.id_paciente='".$_GET['id_pacientes']."';";

		if($resultado=seleccionar($sql,$conn)){
				while ($fila = mysqli_fetch_row($resultado)) {
					
						echo "<div class='info-lista'>
			                  <div class='info-header'>
			                    <div class='nombre-info'>".$fila[3]."  |  ".$fila[5]." <i class='fa fa-caret-down' aria-hidden='true'></i></div>
			                  </div>
			                  <div class='info-body'>

			                    <p class='detalles-info'>Especialista: ".$fila[6]." ".$fila[7]."</p>
			                    <p class='detalles-info'>Especialidad: ".$fila[8]."</p>
			                    <br>
			                    		".$fila[4]."
			                  </div>
			                </div>";
			                     
				}
		}

	}
   ?>
 