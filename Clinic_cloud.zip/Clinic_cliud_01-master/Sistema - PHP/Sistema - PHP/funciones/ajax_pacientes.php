
  <?php 
include "conecxion.php";
include "f_paciente.php";

if (!$conn=conn_Star()) {
    header("location:error.php");
  }
  ?>
<?php 
  session_start();
  if (!isset($_SESSION["nombre"])){
     header("Location:logeo.php");
  }
 ?>
 <?php
 //DATO PERSONALES
	if (isset($_GET["id_paciente"])) {

		$sql="SELECT p.*,ob.nro_afiliado,obs.nombre_obra_soc,ob.estado,es.estado FROM c_c_santino_01.pacientes as p left join ob_social_paciente as ob on p.id_paciente=ob.id_paciente left join obra_social as obs on ob.id_ob_social=obs.id_obra_social left join estados_ob_sociales as es on ob.estado=es.idestado Where p.id_paciente='".$_GET["id_paciente"]."';";

		if($resultado=seleccionar($sql,$conn)){
			while ($fila = mysqli_fetch_row($resultado)) {
				echo $fila[3].",";
				echo $fila[1].",";
				echo $fila[2].",";
				echo $fila[7].",";
				echo $fila[6].",";
				echo $fila[5].",";
				echo $fila[4].",";
				echo $fila[9].",";
				echo $fila[11].",";
				echo $fila[10].",";
				echo $fila[13].",";
			}


		}
	}

	
  
  ?>

  <?php 

	if (isset($_GET["id_pacientes"])) {


		$sql="SELECT c.*,e.apellido,e.nombre,es.especialidad FROM c_c_santino_01.pacientes as p inner join consultas as c on p.id_paciente=c.id_paciente  inner join especialista as e on c.id_especialista=e.id_especialista inner join especialidad as es on e.id_especialidad=es.id_especialidad WHERE p.id_paciente='".$_GET['id_pacientes']."';";

		if($resultado=seleccionar($sql,$conn)){
				while ($fila = mysqli_fetch_row($resultado)) {
					
						echo "<div class='box-card'>
			                        <div class='box-header'>
			                          <div class='fecha'>
			                            <p>".$fila[3]."</p>
			                          </div>
			                          <div class='especialista'>
			                            <p>".$fila[8].":".$fila[6]." ".$fila[7]."</p>
			                          </div>
			                        </div>

			                        <div class='box-body'>
			                          <p>".$fila[4]."</p>
			                        </div>
			                    </div>";
				}
		}
	}
   ?>



 <?php 

	if (isset($_GET["listar"])) {

		$res="";
		$sql="SELECT p.id_paciente,p.dni,p.nombre,p.apellido,p.telefono,p.celular,ob.*,ob_s.nombre_obra_soc,es.estado FROM c_c_santino_01.pacientes as p left join ob_social_paciente as ob on p.id_paciente=ob.id_paciente left join obra_social as ob_s on ob.id_ob_social=ob_s.id_obra_social left join estados_ob_sociales as es on es.idestado=ob.estado WHERE p.dni LIKE '%".$_GET["listar"]."%';";
		
		if($resultado=seleccionar($sql,$conn)){
					$url_agrefar_pas="";
					while ($fila = mysqli_fetch_row($resultado)) {
							//if ($_SESSION["nivel_usuario"]=="0"){
			             	$url_agrefar_pas="<a href='agregar_consulta.php?id_paciente=$fila[0]'>
								              <div  class='circle-btn btn1' alt='Smiley face'><i class='fa fa-plus'></i>
								                  <div class='text t1'><p>Agregar Consulta</p><div class='triangulo'></div></div>
								              </div>
								            </a>";
							$res=$res."<div class='lista'>";
							$res=$res."<div class='paciente'>
							              <div class='nombre datos-personales'>
							                <div>".$fila[1]."</div>
							                <div>".$fila[2]."</div> 
							                <div>".$fila[3]."</div>
							              </div>
							              <div class='info-general'>
							                <div>".$fila[5]."</div>
							                <div>".$fila[4]."</div>
							                <div style='text-align:center;'>$fila[10]</div>
							                <div>".$fila[8]."</div>
							                <div>".$fila[11]."</div>

							              </div>
							           </div>";

			                  $res= $res."<div class='ops'>".$url_agrefar_pas."
							   				

								            <a href='agregar_paciente.php?modificar=$fila[0]'>
								              <div class='circle-btn btn2'><i class='fa fa-pen'></i>
								                <div class='text t2'><p>Editar Paciente</p><div class='triangulo'></div></div>
								              </div>
								            </a>

								            <a href='javascript:openVentana();mostrar_preguntas($fila[0]);mostrar_historial($fila[0]);' >
								              <div class='circle-btn btn3' ><i class='fa fa-folder-open'></i>
								                <div class='text t3'><p>Ver Paciente</p><div class='triangulo'></div></div>
								              </div>
								            </a>

								            <a href='javascript:borrar_paciente($fila[0]);' >
								              <div class='circle-btn btn4'><i class='fa fa-trash-alt'></i>
								                <div class='text t4'><p>Borrar Paciente</p><div class='triangulo'></div></div>
								              </div>
								            </a>

								         </div>";

			                  $res= $res."<a href='javascript:openVentana_menu(),holmundo($fila[0]);'>
									            <div class='puntos'>
									              <i class='fa fa-grip-vertical'></i>
									            </div>
									       </a>

									    </div>";
         	//}  
					}
					echo $res;
		}

	}
   ?>
  


 <?php 

	if (isset($_GET["p_opciones"])) {
		$id=$_GET["p_opciones"];
		$res="";
		//$sql="SELECT * FROM c_c_santino_01.pacientes WHERE id_paciente='".$_GET["p_opciones"]."'";
		
		//if($resultado=seleccionar($sql,$conn)){
		//			while ($fila = mysqli_fetch_row($resultado)) {
					$res=$res."<a href='agregar_consulta.php?id_paciente=$id' class='opcion-menu'>
            						<p>INICIAR CONSULTA hola</p>
          						</a>
          						<div class='opcion-menu' onclick='openVentana();mostrar_preguntas($id);mostrar_historial($id);'>
            						<p>VER EXPEDIENTE</p>
          						</div>
          						<a href='agregar_paciente.php?modificar=$id' class='opcion-menu'>
            						<p>EDITAR PACIENTE</p>
          						</a>
          						<a href='javascript:borrar_paciente($id' class='opcion-menu ops-especial'>
            						<p>BORRAR PACIENTE</p>
          						</a>";					
					
					echo $res;
		//}

	}
  ?>
  
 