  <?php 
include "conecxion.php";

if (!$conn=conn_Star()) {
    header("location:error.php");
  }
  ?>
<?php 
  session_start();
  if (!isset($_SESSION["nombre"])){
     header("Location:logeo.php");
  }
 ?>
 <?php
 	//BUSCAR PACIENTE 
	if (isset($_GET["buscar"])) {

		$sql="SELECT * FROM c_c_santino_01.pacientes WHERE dni='".$_GET["buscar"]."';";

		if($resultado=seleccionar($sql,$conn)){
			while ($fila = mysqli_fetch_row($resultado)) {
				echo $fila[1].",";
				echo $fila[2].",";
				echo $fila[0].", ";
			}
		}
	}

	
  
  ?>