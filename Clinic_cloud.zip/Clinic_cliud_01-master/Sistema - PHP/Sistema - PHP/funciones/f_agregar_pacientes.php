<?php 

	function obra_Social($conn){
		$res="";
		$sql="SELECT * FROM c_c_santino_01.obra_social;";
		if($resultado=seleccionar($sql,$conn)){
			while ($fila = mysqli_fetch_row($resultado)) {
                  $res= $res."<option value=".$fila[0].">".$fila[1]."</option>";
         	}  
		}
		
		return $res;
	}
	function listar_estados($conn){
		$res="";
		$sql="SELECT * FROM c_c_santino_01.estados_ob_sociales;";
		if($resultado=seleccionar($sql,$conn)){
			while ($fila = mysqli_fetch_row($resultado)) 
                  $res= $res."<option value=".$fila[0].">".$fila[1]."</option>";
         	  
		}
		
		return $res;
	}

//MODIFICAR
	function obra_Social_m($conn,$id_p){
		$res="";
		$estado="";
		$sql="SELECT ob.id_obra_social FROM c_c_santino_01.ob_social_paciente as ob_p left join obra_social as ob on ob_p.id_ob_social=ob.id_obra_social where id_paciente='$id_p';";
		if($resultado=seleccionar($sql,$conn)){
			while ($fila = mysqli_fetch_row($resultado)) 
                  $estado=$fila[0];
         	  
		}
		$sql="SELECT * FROM c_c_santino_01.obra_social;";
		if($resultado=seleccionar($sql,$conn)){
			while ($fila = mysqli_fetch_row($resultado)) {
					if ($estado==$fila[0]) {
        		          $res= $res."<option selected value=".$fila[0].">".$fila[1]."</option>";
					}else{
		                  $res= $res."<option value=".$fila[0].">".$fila[1]."</option>";
					}
         	}  
		}
		
		return $res;
	}
	function listar_estados_m($conn,$id_p){
		$res="";
		$estado="";
		$sql="SELECT idestado FROM c_c_santino_01.ob_social_paciente as ob_p left join estados_ob_sociales as es on es.idestado=ob_p.estado where id_paciente='$id_p';";
		if($resultado=seleccionar($sql,$conn)){
			while ($fila = mysqli_fetch_row($resultado)) 
                  $estado=$fila[0];
         	  
		}
		$sql="SELECT * FROM c_c_santino_01.estados_ob_sociales;";
		if($resultado=seleccionar($sql,$conn)){
			while ($fila = mysqli_fetch_row($resultado)) {
					if ($estado==$fila[0]) {
        		          $res= $res."<option selected value=".$fila[0].">".$fila[1]."</option>";
					}else{
		                  $res= $res."<option value=".$fila[0].">".$fila[1]."</option>";
					}
         	}  
		}
		
		return $res;
	}
//END MODIFICAR

	function validar_datos_pacientes($conn,$datos_array){
			$sql_u="INSERT INTO `c_c_santino_01`.`pacientes` (`nombre`, `apellido`, `dni`, `telefono`, `fech_nacimiento`, `sexo`, `direccion`, `localidad`, `celular`) VALUES ('$datos_array[1]','$datos_array[2]','$datos_array[0]','$datos_array[4]','$datos_array[3]','$datos_array[6]','$datos_array[10]','$datos_array[11]','$datos_array[5]');";
					
			$id_anterior= agregar_2($sql_u,$conn);
			$sql_ob="INSERT INTO `c_c_santino_01`.`ob_social_paciente` (`id_ob_social`, `id_paciente`, `nro_afiliado`, `estado`) VALUES ('$datos_array[12]', '$id_anterior', '$datos_array[13]', '$datos_array[14]');";
		
			$sql_f="INSERT INTO `c_c_santino_01`.`familiares` (`id_paciente`, `nombre_tutor`, `apellido_tutor`, `dni_tutor`) VALUES ('$id_anterior', '$datos_array[7]', '$datos_array[8]', '$datos_array[9]');";

			agregar($sql_ob,$conn);
			agregar($sql_f,$conn);
			
			return $sql_f."<br>".$sql_ob."<br>";
		
	}

	function buscar_paciente($paciente,$conn){
		 $sqlm="SELECT * FROM c_c_santino_01.pacientes as p left join familiares as f on p.id_paciente=f.id_paciente left Join ob_social_paciente as ob_p on p.id_paciente=ob_p.id_paciente left join obra_social as ob on ob_p.id_ob_social=ob.id_obra_social WHERE p.id_paciente='".$paciente."';";
		 if ($resultado=seleccionar($sqlm,$conn)) {
		 	return $resultado;
		 }
	}
?>
