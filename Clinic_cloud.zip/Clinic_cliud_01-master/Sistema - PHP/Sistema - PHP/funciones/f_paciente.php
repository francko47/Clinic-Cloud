<?php 

	function Listar_pacientes($conn){
		$res="";
		$sql="SELECT p.id_paciente,p.dni,p.nombre,p.apellido,p.telefono,p.celular,ob.*,ob_s.nombre_obra_soc,es.estado FROM c_c_santino_01.pacientes as p left join ob_social_paciente as ob on p.id_paciente=ob.id_paciente left join obra_social as ob_s on ob.id_ob_social=ob_s.id_obra_social left join estados_ob_sociales as es on es.idestado=ob.estado;";
		if($resultado=seleccionar($sql,$conn)){
			$url_agrefar_pas="";
			$url_modificar_pas="";
             }

			while ($fila = mysqli_fetch_row($resultado)) {
				if ($_SESSION["nivel_usuario"]!="1"){
					$url_agrefar_pas="<a href='agregar_consulta.php?id_paciente=$fila[0]'>
					              <div  class='circle-btn btn1' alt='Smiley face'><i class='fa fa-plus'></i>
					                  <div class='text t1'><p>Agregar Consulta</p><div class='triangulo'></div></div>
					              </div>
					            </a>";
				}else{
					$url_agrefar_pas="";
				}
             	if ($_SESSION["nivel_usuario"]!="2"){
					$url_modificar_pas=" <a href='agregar_paciente.php?modificar=$fila[0]'>
					              <div class='circle-btn btn2'><i class='fa fa-pen'></i>
					                <div class='text t2'><p>Editar Paciente</p><div class='triangulo'></div></div>
					              </div>
					            </a>";
				}else{
					$url_modificar_pas="";
				}
				$res=$res."<div class='lista'>";
				$res=$res."<div class='paciente'>
				              <div class='nombre datos-personales'>
				                <div>".$fila[1]."</div>
				                <div>".$fila[2]."</div> 
				                <div>".$fila[3]."</div>
				              </div>
				              <div class='info-general'>
				                <div>".$fila[5]."</div>
				                <div>".$fila[4]."</div>
				                <div style='text-align:center;'>$fila[10]</div>
				                <div>".$fila[8]."</div>
				                <div>".$fila[11]."</div>

				              </div>
				           </div>";

                  $res= $res."<div class='ops'>".$url_agrefar_pas."".$url_modificar_pas."
				   				

					           

					            <a href='javascript:openVentana();mostrar_preguntas($fila[0]);mostrar_historial($fila[0]);' >
					              <div class='circle-btn btn3' ><i class='fa fa-folder-open'></i>
					                <div class='text t3'><p>Ver Paciente</p><div class='triangulo'></div></div>
					              </div>
					            </a>

					            <a href='javascript:borrar_paciente($fila[0]);' >
					              <div class='circle-btn btn4'><i class='fa fa-trash-alt'></i>
					                <div class='text t4'><p>Borrar Paciente</p><div class='triangulo'></div></div>
					              </div>
					            </a>

					         </div>";

                  $res= $res."<a href='javascript:openVentana_menu(),holamundo($fila[0]);'>
						            <div class='puntos'>
						              <i class='fa fa-grip-vertical'></i>
						            </div>
						          </a>

						    </div>";
         	//}  
		}
		
		return $res;
	}

	

 ?>
