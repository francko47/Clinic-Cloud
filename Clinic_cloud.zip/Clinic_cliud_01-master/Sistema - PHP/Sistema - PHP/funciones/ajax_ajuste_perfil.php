  <?php 
include "conecxion.php";

	if (!$conn=conn_Star()) {
    	header("location:error.php");
	}
  ?>

<?php 
	function agregar_ob_es($conn,$id_ob,$id_es){
	
		$sql="INSERT INTO `c_c_santino_01`.`ob_sociales_especialista` (`id_ob_sociales`, `id_especialista`) VALUES ('$id_ob', '$id_es');";
		//echo $sql;
			if(agregar($sql,$conn))
				return true;
			else
				return false;
	}
	function eliminar_ob_es($conn,$id_ob,$id_es){
	
		$sql="DELETE FROM `c_c_santino_01`.`ob_sociales_especialista` WHERE `id_ob_sociales`='$id_ob' and`id_especialista`='$id_es' ";

			if(agregar($sql,$conn))
				return true;
			else
				return false;
	}

	function Listar_ob_es_1($conn,$id){
		$res="";
		$es_ob="";
		
			$sql="SELECT id_obra_social,id_especialista,ob.nombre_obra_soc FROM obra_social as ob left join ob_sociales_especialista as ob_e on ob.id_obra_social=ob_e.id_ob_sociales and id_especialista='1' ; ";

				if($resultado=seleccionar($sql,$conn)){
					$res=$res."<select id='ob_social'>";
					while ($fila = mysqli_fetch_row($resultado)) {
						if ($fila[1]==null) {
							$res=$res."<option value='".$fila[0]."'>".$fila[2]."</option>";
						}
		         	}
					$res=$res."</select>";
				}
		
		return $res;
	}

	function Listar_ob_es_2($conn,$id){
		$res="";
		$es_ob="";
		
			$sql="SELECT id_obra_social,id_especialista,ob.nombre_obra_soc FROM obra_social as ob left join ob_sociales_especialista as ob_e on ob.id_obra_social=ob_e.id_ob_sociales and id_especialista='1' ; ";
				
				if($resultado=seleccionar($sql,$conn)){
					$res=$res."<table>";
					while ($fila = mysqli_fetch_row($resultado)) {
						if ($fila[1]!=null) {
							$res=$res."<tr>
					                     <td>".$fila[2]."</td>
					                     <td><a href='javascript:eliminar_ob_es_l(".$fila[0].",".$id.");Listar_ob_es_0(".$id.")' >elimina<a/></td>
					                   </tr>";
						}
		         	}
					$res=$res."</table>";
				}
		
		return $res;
	}

                   
?>
<?php ///////////////////////////////////////////////////////////////////////////////// ?>    
<?php 
if (isset($_GET['listar_ob_1'])) {
	echo Listar_ob_es_1($conn,$_GET['listar_ob_1']);
}
if (isset($_GET['listar_ob_2'])) {
	echo "string";
	echo Listar_ob_es_2($conn,$_GET['listar_ob_2']);
}
if (isset($_GET['eliminar_ob'])) {
	echo eliminar_ob_es($conn,$_GET['eliminar_ob'],$_GET['id_es']);
}
if (isset($_GET['agregar_ob'])) {
	echo "puto".agregar_ob_es($conn,$_GET['agregar_ob'],$_GET['id_es']);
}

 ?>        