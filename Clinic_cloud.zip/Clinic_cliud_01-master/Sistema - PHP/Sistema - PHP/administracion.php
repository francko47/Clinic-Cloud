<?php 
$path_css="css/";
$path_js="";
 ?>
  <!-- CONECCION A LA BASE DE DATOS -->
  <?php 
include "funciones/conecxion.php";
if (!$conn=conn_Star()) {
    header("location:error.php");
  }
  ?>
<!-- VALIDAR LOGEO -->
<?php 
  session_start();
  if (!isset($_SESSION["nombre"])){
     header("Location:logeo.php");
  }
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
        <?php include "funciones/header.html" ?>


    <link href="https://fonts.googleapis.com/css?family=Roboto:300" rel="stylesheet">

		
		<link rel="stylesheet" type="text/css" href="<?php echo $path_css; ?>estilos_generales.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo $path_css; ?>estilos_administracion.css" />


	<script type="text/javascript" src="<?php echo $path_js; ?>jquery-3.3.1.min.js"></script>

	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >
  <link rel="stylesheet" type="text/css" href="css/font.css">

	<script>
        function Mostrar() {
            document.getElementById("menu").style.display = "block";
            document.getElementById("cuerpo").style.marginLeft = "230px";
        }

        function Ocultar() {
            document.getElementById("menu").style.display = "none";
            document.getElementById("cuerpo").style.marginLeft = "0px";
        }

        function Mostrar_Ocultar() {
          var menu=document.getElementById("menu");

          if (menu.style.display=="none") {
            Mostrar();
          }else{
            Ocultar();
          }
        }

    </script>

</head>
<body>


<div class="container">

	<?php 
include "menu.php";
 ?>    

    <section class="cuerpo" id="cuerpo">
    	<h2>

    		<a id="abrir" class="abrir-cerrar" href="javascript:void(0)" onclick="Mostrar_Ocultar()">
            	<div class="abrir-menu"><i class="fas fa-align-justify"></i></div>
         	</a>

         	Administracion

    		<img  class="logo-responsive" src="img/logo.png" alt="">
    	</h2>

     <div class="container-section">
        <a href="turnos.php">
          <div class="caja wrap-1">
            <div class="body-caja">
              <div class="icon">
                <i class="fa fa-calendar-alt"></i>
              </div>
              <div class="name">
                <h3>Turnos</h3>
              </div>
            </div>
            <div class="footer-caja">
              <h3>Mas informacion <i class="fas fa-arrow-alt-circle-right"></i></h3>
            </div>
          </div>
        </a>
        <a href="paciente.php">
          <div class="caja wrap-2">
            <div class="body-caja">
              <div class="icon">
                <i class="fa fa-users"></i>
              </div>
              <div class="name">
                <h3>Pacientes</h3>
              </div>
            </div>
            <div class="footer-caja">
              <h3>Mas informacion <i class="fas fa-arrow-alt-circle-right"></i></h3>
            </div>
          </div>
        </a>
        <a href="reportes.php">
          <div class="caja wrap-3">
            <div class="body-caja">
              <div class="icon">
                <i class="fa fa-clipboard-list"></i>
              </div>
              <div class="name">
                <h3>Reportes</h3>
              </div>
            </div>
            <div class="footer-caja">
              <h3>Mas informacion <i class="fas fa-arrow-alt-circle-right"></i></h3>
            </div>
          </div>
        </a>
        <a href="#">
          <div class="caja wrap-4">
            <div class="body-caja">
              <div class="icon">
                <i class="fa fa-hand-holding-usd"></i>
              </div>
              <div class="name">
                <h3>Liquidacion</h3>
              </div>
            </div>
            <div class="footer-caja">
              <h3>Mas informacion <i class="fas fa-arrow-alt-circle-right"></i></h3>
            </div>
          </div>
        </a>
        <a href="alquiler.php">
          <div class="caja wrap-5">
            <div class="body-caja">
              <div class="icon">
                <i class="fa fa-book"></i>
              </div>
              <div class="name">
                <h3>Alquiler</h3>
              </div>
            </div>
            <div class="footer-caja">
              <h3>Mas informacion <i class="fas fa-arrow-alt-circle-right"></i></h3>
            </div>
          </div>
        </a>
        <a href="ob_sociales.php">
          <div class="caja wrap-6">
            <div class="body-caja">
              <div class="icon">
                <i class="fa fa-hospital"></i>
              </div>
              <div class="name">
                <h3>OB Sociales</h3>
              </div>
            </div>
            <div class="footer-caja">
              <h3>Mas informacion <i class="fas fa-arrow-alt-circle-right"></i></h3>
            </div>
          </div>
        </a>

        <hr>

         <a href="usuarios.php">
          <div class="caja wrap-6">
            <div class="body-caja">
              <div class="icon">
                <i class="fa fa-hospital"></i>
              </div>
              <div class="name">
                <h3>Usuarios</h3>
              </div>
            </div>
            <div class="footer-caja">
              <h3>Mas informacion <i class="fas fa-arrow-alt-circle-right"></i></h3>
            </div>
          </div>
        </a>

        <a href="ajustes_perfil.php">
          <div class="caja wrap-6">
            <div class="body-caja">
              <div class="icon">
                <i class="fa fa-hospital"></i>
              </div>
              <div class="name">
                <h3>Mi perfil</h3>
              </div>
            </div>
            <div class="footer-caja">
              <h3>Mas informacion <i class="fas fa-arrow-alt-circle-right"></i></h3>
            </div>
          </div>
        </a>

      </div>
    
    </section>




</div>





<scripst src="js/jquery.min.js"></scripst>

	
</body>
</html>