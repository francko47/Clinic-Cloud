

<?php 

  session_start();
  if (isset($_SESSION["nombre"])){
  }else{
    header("Location:../Logeo.php");
  }
  ?>
 <!--____________INCLUYO LOS ARCHIOS NECESARIOS_____________________-->
<?php
require('../fpdf.php');
include ("../funciones/conecxion.php");









class PDF extends FPDF
{
// Cargar los datos
function LoadData($sql)
{
        $conn=conn_Star();
        if ($result=seleccionar($sql,$conn)){   
         return $result;
         }

   
}

// Tabla simple
    function BasicTable($header, $data)
    {
        // Cabecera
        foreach($header as $col)
            $this->Cell(40,7,$col,1);
        $this->Ln();
        // Datos
        foreach($data as $row)
        {
            foreach($row as $col)
                $this->Cell(40,6,$col,1);
            $this->Ln();
        }
    }

// Una tabla más completa
    function cabecera()
    {
        // Anchuras de las columnas
        $w = array(40, 35, 45, 40);
        // Cabeceras
            $this->Image('../img/logo.png',10,10,0,0,'PNG');
            $this->Cell(50,65,"Reportes diarios",0,0,'C');
            $this->Ln(5);
            $this->SetFont('Arial','',13);
            $hoy = date("Y-m-d");
            $this->Cell(330,65,"fecha: ".$hoy,0,0,'C');
           // $this->Cell(100,35,"c.c Santino",0,0,'C');

            $this->Ln(40);
         /*    $this->Ln();
        // Datos
       foreach($data as $row)
        {
            $this->Cell($w[0],6,$row[0],'LR');
            $this->Cell($w[1],6,$row[1],'LR');
            $this->Cell($w[2],6,number_format($row[2]),'LR',0,'R');
            $this->Cell($w[3],6,number_format($row[3]),'LR',0,'R');
            $this->Ln();
        }
        // Línea de cierre
        $this->Cell(array_sum($w),0,'','T');
       */ 
    }

// Tabla coloreada
    function FancyTable($header, $data)
    {
        // Colores, ancho de línea y fuente en negrita
        $this->SetFillColor(127,154,252);//color fondo
        $this->SetTextColor(255);
        $this->SetDrawColor(200,200,200);//color lineras
        $this->SetLineWidth(.0);
        $this->SetFont('','B');
        // Cabecera
        $w = array(45, 35, 40, 40, 20);
        $copago_total=0;
        $pago_total=0;
        for($i=0;$i<count($header);$i++)
            $this->Cell($w[$i],11,$header[$i],1,0,'C',true);
        $this->Ln();
        // Restauración de colores y fuentes
        $this->SetFillColor(234,245,255);
        $this->SetTextColor(14);
        $this->SetFont('');
        $this->SetFont('Arial','',12);
        // Datos
        $fill = false;
        while ($fila=mysqli_fetch_array($data)) 
        {
            $this->Cell($w[0],7,$fila[0]." ".$fila[1],'LR',0,'L',$fill);
            $this->Cell($w[1],7,$fila[2],'LR',0,'L',$fill);
            $this->Cell($w[2],7,$fila[3],'LR',0,'C',$fill);
            $this->Cell($w[3],7,$fila[4],'LR',0,'R',$fill);
            $this->Cell($w[4],7," ".$fila[6].':'.$fila[7],'LR',0,'R',$fill);

            $this->Ln();
            $fill = !$fill;
            if ($fila[3]!="") {
                $copago_total+=$fila[3];
                $pago_total+=$fila[4];
            }
        }
        $this->Cell(180,7,"Total a recaudar: $".$copago_total."     recaudado: $".$pago_total,'LR',1,'R',$fill);

        // Línea de cierre
        $this->Cell(array_sum($w),0,'','T');

    }
}


$sql_pdf=$_SESSION["reporte_sql"];
#SELECT * FROM emeironta.pacientes WHERE cuil_paciente='1234567';
echo $sql_pdf;


$pdf = new PDF();
// Títulos de las columnas
$header = array('Nombre Apellido','Ob Social','copago','monto pagado','hora');
// Carga de datos
$data = $pdf->LoadData($sql_pdf);
$pdf->SetFont('Arial','',19);
$pdf->AddPage();
$pdf->cabecera();
$pdf->SetFont('Arial','',13);
$pdf->FancyTable($header,$data);
$pdf->Output("F","docu",true);

//header("Location:pdf/docu");
?>
<script type="text/javascript">
window.location="docu";
//alert("Se agrego correctamente");
</script>