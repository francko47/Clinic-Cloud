<?php 
$path_css="css/";
$path_js="";
 ?>

   <!-- CONECCION A LA BASE DE DATOS -->
  <?php 
include "funciones/conecxion.php";
if (!$conn=conn_Star()) {
    header("location:error.php");
  }
  ?>
<!-- VALIDAR LOGEO -->
<?php 
  session_start();
  if (!isset($_SESSION["nombre"])){
     header("Location:logeo.php");
  }
 ?>
 <!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>

        <?php include "funciones/header.html" ?>

    <link href="https://fonts.googleapis.com/css?family=Roboto:300" rel="stylesheet">

		
		<link rel="stylesheet" type="text/css" href="<?php echo $path_css;?>estilos_generales.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo $path_css;?>estilos_reportes.css" />


	<script type="text/javascript" src="jquery-3.3.1.min.js"></script>

	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >
  <link rel="stylesheet" type="text/css" href="css/font.css">

	<script>
       function Mostrar() {
            document.getElementById("menu").style.display = "block";
            document.getElementById("cuerpo").style.marginLeft = "230px";
        }

        function Ocultar() {
            document.getElementById("menu").style.display = "none";
            document.getElementById("cuerpo").style.marginLeft = "0px";
        }

        function Mostrar_Ocultar() {
          var menu=document.getElementById("menu");

          if (menu.style.display=="none") {
            Mostrar();
          }else{
            Ocultar();
          }
        }
    </script>

</head>
<body>


<div class="container">

  <?php include "menu.php"; ?>      
	      

    <section class="cuerpo" id="cuerpo">
    	<h2> 
    		<a id="abrir" class="abrir-cerrar" href="javascript:void(0)" onclick="Mostrar_Ocultar()">
              <div class="abrir-menu"><i class="fas fa-align-justify"></i></div>
          </a>

         	Reportes

    		<img  class="logo-responsive" src="img/logo.png" alt="">
    	</h2>
      <div class="container-reports"> 

        <a href="R1.php"><div class="block-report">
          <div class="name-report">Diario por Profesional <i class="fa fa-calendar-alt"></i></div>
        </div></a>
        <a href="R2.php"><div class="block-report">
          <div class="name-report">Pac. que no Asistieron <i class="fa fa-calendar-alt"></i></div>
        </div></a>
        <a href=""><div class="block-report">
          <div class="name-report">Contable    Diario <i class="fa fa-calendar-alt"></i></div>
        </div></a>
        <a href="R3.php"><div class="block-report">
          <div class="name-report">Pac. Atendidos por OB.S <i class="fa fa-calendar-alt"></i></div>
        </div></a>
        <a href=""><div class="block-report">
          <div class="name-report">Turnos por Recep. <i class="fa fa-calendar-alt"></i> </div>
        </div></a>

     </div>
     


<!--
1) Reporte diario por profesional. (Pacientes atendidos, con los montos y obra sociales)
2) Reportes de pacientes que no vienen por intervalo de tiempo.
3)Reporte contable diario 
4)cantidad de pacientes atendidos por obra social.
5) cantidad de turnos tomados por cada recepcionista 
  --> 
    </section>




</div>





<scripst src="js/jquery.min.js"></scripst>

	
</body>
</html>