<?php 
$path_css="css/";
$path_js="";
 ?>

 <?php 
include "funciones/conecxion.php";

$conn=conn_Star();
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">

	<title>Document</title>


    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">

	<link rel="stylesheet" type="text/css" href="<?php echo $path_css;?>estilos_generales.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo $path_css;?>estilos_clinico.css" />

	<script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >
  <link rel="stylesheet" type="text/css" href="css/font.css">

	<script src="menu.js"></script>

	<script type="text/javascript" src="jquery-3.3.1.min.js"></script>

     <script type="text/javascript">
          $(document).ready(function(){
          $('ul.tabs li a:first').addClass('active');
          $('.secciones article').hide();
          $('.secciones article:first').show();

          $('ul.tabs li a').click(function(){
            $('ul.tabs li a').removeClass('active');
            $(this).addClass('active');
            $('.secciones article').hide();

            var activeTab = $(this).attr('href');
            $(activeTab).show();
            return false;
          });
        });
    </script>
	


    <script>
         function Mostrar() {
            document.getElementById("menu").style.display = "block";
            document.getElementById("cuerpo").style.marginLeft = "230px";
        }

        function Ocultar() {
            document.getElementById("menu").style.display = "none";
            document.getElementById("cuerpo").style.marginLeft = "0px";
        }

        function Mostrar_Ocultar() {
          var menu=document.getElementById("menu");

          if (menu.style.display=="none") {
            Mostrar();
          }else{
            Ocultar();
          }
        }
    </script>


    <script type="text/javascript">
      function openVentana_add_paciente(){
        $(".ventana-add-paciente").show();
      }
      function closeVentana_add_paciente(){
        $(".ventana-add-paciente").hide();
      }
  </script>


    <script type="text/javascript">
      $(document).ready(function(){
      $(".box-body").hide();
      $(".box-header").click(function(event){
               var desplegable = $(this).next();
               $('.box-body').not(desplegable).slideUp('fast');
                desplegable.slideToggle('fast');
                event.preventDefault();
                })
          });
    </script>



 </head>
<body>
<div class="container">

  <?php include "menu.php"; ?>      
	  

    <section class="cuerpo" id="cuerpo">

    	<h2 class="cabezote">
            Administracion 
       
        <a id="abrir" class="abrir-cerrar" href="javascript:void(0)" onclick="mostrar()">
            <div class="abrir-menu"><i class="fas fa-align-justify"></i></div>
         </a>

      </h2>  

      <a href="javascript:openVentana_add_paciente();" class="agregar">Agregar</a>
      
    	
	</section>

</div>







<div class="ventana-add-paciente">
    <a class="btn-close-paciente" href="javascript:closeVentana_add_paciente();"><i class="fa fa-times" aria-hidden="true"></i></a>

    <div class="wrap-add-paciente">

        <h1 class="title-clinico title-p title-add"> Personales</h1>

            <form action="" class="form-historia">
                <div class="input-clinico">
                    <i class="far fa-user input-add" aria-hidden="true"> <h5>Dni</h5> </i>
                    <input type="text" placeholder="Dni" >
                 </div>

                <div class="input-clinico">
                    <i class="far fa-user input-add" aria-hidden="true"> <h5>Nombre</h5> </i>
                    <input type="text" placeholder="Nombre" >
                </div>

                <div class="input-clinico">
                    <i class="far fa-user input-add" aria-hidden="true"> <h5>Apellido</h5> </i>
                    <input type="text" placeholder="Apellido" >
                </div>

                 <div class="input-clinico">
                    <i class="far fa-user input-add" aria-hidden="true"> <h5>Fech. Nac.</h5> </i>
                    <input type="date" placeholder="Fecha de Nacimiento"  class="input-clinico-top" >
                </div>

                 <div class="input-clinico">
                    <i class="far fa-user input-add" aria-hidden="true"> <h5>Telefono</h5> </i>
                    <input type="text" placeholder="Telefono" >
                </div>

                 <div class="input-clinico">
                    <i class="far fa-user input-add" aria-hidden="true"> <h5>Celular</h5> </i>
                    <input type="text" placeholder="Celular" >
                </div>

                 <div class="input-clinico">
                    <i class="fa fa-bars" aria-hidden="true"> <h5>Sexo</h5> </i>
                    <select>
                      <option value="todo">Ninguno</option>
                      <option value="masculino">Masculino</option>
                      <option value="femenino">Femenino</option>
                    </select>
                 </div>



                <h1 class="title-clinico title-add"> Demograficos</h1>

                 <div class="input-clinico">
                    <i class="far fa-user input-add" aria-hidden="true"> <h5>Pais</h5> </i>
                    <input type="text" placeholder="Provincia"  class="input-clinico-top" >
                </div>

                 <div class="input-clinico">
                    <i class="far fa-user input-add" aria-hidden="true"> <h5>Provincia</h5> </i>
                    <input type="text" placeholder="Direccion"  class="input-clinico-top" >
                </div>

                 <div class="input-clinico">
                    <i class="far fa-user input-add" aria-hidden="true"> <h5>Ciudad</h5> </i>
                    <input type="text" placeholder="Provincia"  class="input-clinico-top" >
                </div>

                 <div class="input-clinico">
                    <i class="far fa-user input-add" aria-hidden="true"> <h5>Cod. Postal</h5> </i>
                    <input type="text" placeholder="Direccion"  class="input-clinico-top" >
                </div>

                <div class="input-clinico">
                    <i class="far fa-user input-add" aria-hidden="true"> <h5>Direccion</h5> </i>
                    <input type="text" placeholder="Direccion"  class="input-clinico-top" >
                </div>



                 <h1 class="title-clinico title-add"> Obra Social</h1>


                 <div class="input-clinico">
                    <i class="far fa-user input-add" aria-hidden="true"> <h5>Obra Social</h5> </i>
                    <select class="input-clinico-top">
                      <option value="todo">Ninguna</option>
                      <option value="masculino">ODIE</option>
                      <option value="femenino">FANZONA</option>
                    </select>
                </div>

                 <div class="input-clinico">
                    <i class="far fa-user input-add" aria-hidden="true"> <h5>N° Afiliado</h5> </i>
                    <input type="text" placeholder="Numero Afiliado"  class="input-clinico-top">
                </div>

                 <div class="input-clinico">
                    <i class="fa fa-bars" aria-hidden="true"> <h5>Estado</h5> </i>
                    <select class="input-clinico-top">
                      <option value="todo">Valido</option>
                      <option value="masculino">Masculino</option>
                      <option value="femenino">Femenino</option>
                    </select>
                 </div>

            </form>
      
    </div>
    
</div>

















<div class="ventana"> 
  <a class="btn-close-clinico" href="javascript:closeVentana();"><i class="fa fa-times" aria-hidden="true"></i></a>


  <div class="wrap-clinico">
            <ul class="tabs">
                <li><a href="#tab1"><span class="fa fa-home"></span><span class="tab-text">Informacion</span></a></li>
                <li><a href="#tab2"><span class="fa fa-group"></span><span class="tab-text">Consultas</span></a></li>
                <li><a href="#tab3"><span class="fa fa-briefcase"></span><span class="tab-text">Estudios</span></a></li>
                <li><a href="#tab4"><span class="fa fa-bookmark"></span><span class="tab-text">Antecedentes</span></a></li>
            </ul>

            <div class="secciones">
                <article id="tab1">
                    <h1 class="title-clinico t1">Datos Personales</h1>

                    <form action="" class="form-historia">
                        <div class="input-clinico">
                            <i class="far fa-user" aria-hidden="true"> <h5>Dni</h5> </i>
                            <input type="text" placeholder="Dni" >
                         </div>

                        <div class="input-clinico">
                            <i class="far fa-user" aria-hidden="true"> <h5>Nombre</h5> </i>
                            <input type="text" placeholder="Nombre" >
                        </div>

                        <div class="input-clinico">
                            <i class="far fa-user" aria-hidden="true"> <h5>Apellido</h5> </i>
                            <input type="text" placeholder="Apellido" >
                        </div>

                         <div class="input-clinico">
                            <i class="far fa-user" aria-hidden="true"> <h5>Provincia</h5> </i>
                            <input type="text" placeholder="Provincia"  class="input-clinico-top" >
                        </div>

                         <div class="input-clinico">
                            <i class="far fa-user" aria-hidden="true"> <h5>Direccion</h5> </i>
                            <input type="text" placeholder="Direccion"  class="input-clinico-top" >
                        </div>

                         <div class="input-clinico">
                            <i class="far fa-user" aria-hidden="true"> <h5>Fech. Nac.</h5> </i>
                            <input type="date" placeholder="Fecha de Nacimiento"  class="input-clinico-top" >
                        </div>

                         <div class="input-clinico">
                            <i class="far fa-user" aria-hidden="true"> <h5>Telefono</h5> </i>
                            <input type="text" placeholder="Telefono" >
                        </div>

                         <div class="input-clinico">
                            <i class="far fa-user" aria-hidden="true"> <h5>Celular</h5> </i>
                            <input type="text" placeholder="Celular" >
                        </div>

                         <div class="input-clinico">
                            <i class="fa fa-bars" aria-hidden="true"> <h5>Sexo</h5> </i>
                            <select>
                              <option value="todo">Ninguno</option>
                              <option value="masculino">Masculino</option>
                              <option value="femenino">Femenino</option>
                            </select>
                         </div>


                         <h1 class="title-clinico t2">Datos Personales</h1>


                         <div class="input-clinico">
                            <i class="far fa-user" aria-hidden="true"> <h5>Obra Social</h5> </i>
                            <select class="input-clinico-top">
                              <option value="todo">Ninguna</option>
                              <option value="masculino">ODIE</option>
                              <option value="femenino">FANZONA</option>
                            </select>
                        </div>

                         <div class="input-clinico">
                            <i class="far fa-user" aria-hidden="true"> <h5>N° Afiliado</h5> </i>
                            <input type="text" placeholder="Numero Afiliado"  class="input-clinico-top">
                        </div>

                         <div class="input-clinico">
                            <i class="fa fa-bars" aria-hidden="true"> <h5>Estado</h5> </i>
                            <select class="input-clinico-top">
                              <option value="todo">Valido</option>
                              <option value="masculino">Masculino</option>
                              <option value="femenino">Femenino</option>
                            </select>
                         </div>

                    </form>
                </article>
                <article id="tab2">
                    <h1 class="title-clinico ">Consultas</h1>

                    <div class="filtro-consulta">
                      <form action="">
                        <div class="input-clinico input-consultas">
                            <i class="far fa-user" aria-hidden="true"> <h5>Fecha Desde</h5> </i>
                            <input type="date" placeholder="Fecha Desde"  class="input-clinico-top">
                        </div>
                        <div class="input-clinico input-consultas">
                            <i class="far fa-user" aria-hidden="true"> <h5>Fecha Hasta</h5> </i>
                            <input type="date" placeholder="Fecha Hasta"  class="input-clinico-top">
                        </div>

                            <input type="submit" value="Filtrar"  class="input-clinico-submit">

                      </form>
                    </div>

                    <div class="box-card">
                        <div class="box-header">
                          <div class="fecha">
                            <p>17/07/2017</p>
                          </div>
                          <div class="especialista">
                            <p>Especialidad : Especialista</p>
                          </div>
                        </div>

                        <div class="box-body">
                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque sequi molestiae possimus adipisci dignissimos consectetur laboriosam, quidem, illum nobis. Facilis repellendus perspiciatis obcaecati soluta illo, voluptatem labore numquam, deleniti aliquid.</p>
                        </div>
                    </div>

                    <div class="box-card">
                        <div class="box-header">
                          <div class="fecha">
                            <p>17/07/2017</p>
                          </div>
                          <div class="especialista">
                            <p>Especialidad : Especialista</p>
                          </div>
                        </div>

                        <div class="box-body">
                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque sequi molestiae possimus adipisci dignissimos consectetur laboriosam, quidem, illum nobis. Facilis repellendus perspiciatis obcaecati soluta illo, voluptatem labore numquam, deleniti aliquid.</p>
                        </div>
                    </div>

                    <div class="box-card">
                        <div class="box-header">
                          <div class="fecha">
                            <p>17/07/2017</p>
                          </div>
                          <div class="especialista">
                            <p>Especialidad : Especialista</p>
                          </div>
                        </div>

                        <div class="box-body">
                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque sequi molestiae possimus adipisci dignissimos consectetur laboriosam, quidem, illum nobis. Facilis repellendus perspiciatis obcaecati soluta illo, voluptatem labore numquam, deleniti aliquid.</p>
                        </div>
                    </div>

                    <div class="box-card">
                        <div class="box-header">
                          <div class="fecha">
                            <p>17/07/2017</p>
                          </div>
                          <div class="especialista">
                            <p>Especialidad : Especialista</p>
                          </div>
                        </div>

                        <div class="box-body">
                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque sequi molestiae possimus adipisci dignissimos consectetur laboriosam, quidem, illum nobis. Facilis repellendus perspiciatis obcaecati soluta illo, voluptatem labore numquam, deleniti aliquid.</p>
                        </div>
                    </div>

                </article>
                <article id="tab3">
                    <h1 class="title-clinico ">Estudios</h1>

                    <div class="filtro-consulta">
                      <form action="">
                        <div class="input-clinico input-consultas">
                            <i class="far fa-user" aria-hidden="true"> <h5>Fecha Desde</h5> </i>
                            <input type="date" placeholder="Fecha Desde"  class="input-clinico-top">
                        </div>
                        <div class="input-clinico input-consultas">
                            <i class="far fa-user" aria-hidden="true"> <h5>Fecha Hasta</h5> </i>
                            <input type="date" placeholder="Fecha Hasta"  class="input-clinico-top">
                        </div>

                            <input type="submit" value="Filtrar"  class="input-clinico-submit">

                      </form>
                    </div>

                    <div class="box-card">
                        <div class="box-header">
                          <div class="fecha">
                            <p>17/07/2017</p>
                          </div>
                          <div class="especialista">
                            <p>Especialidad : Especialista</p>
                          </div>
                        </div>

                        <div class="box-body">
                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque sequi molestiae possimus adipisci dignissimos consectetur laboriosam, quidem, illum nobis. Facilis repellendus perspiciatis obcaecati soluta illo, voluptatem labore numquam, deleniti aliquid.</p>           

                         <div class="input-estudio">
                            <input type="file" class="input-file-estudio">
                          </div>                   
                          
                        </div>
                    </div>

                    <div class="box-card">
                        <div class="box-header">
                          <div class="fecha">
                            <p>17/07/2017</p>
                          </div>
                          <div class="especialista">
                            <p>Especialidad : Especialista</p>
                          </div>
                        </div>

                        <div class="box-body">
                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque sequi molestiae possimus adipisci dignissimos consectetur laboriosam, quidem, illum nobis. Facilis repellendus perspiciatis obcaecati soluta illo, voluptatem labore numquam, deleniti aliquid.</p>

                          <div class="input-estudio">
                            <input type="file" class="input-file-estudio">
                          </div>
                          
                        </div>
                    </div>

                    <div class="box-card">
                        <div class="box-header">
                          <div class="fecha">
                            <p>17/07/2017</p>
                          </div>
                          <div class="especialista">
                            <p>Especialidad : Especialista</p>
                          </div>
                        </div>

                        <div class="box-body">
                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque sequi molestiae possimus adipisci dignissimos consectetur laboriosam, quidem, illum nobis. Facilis repellendus perspiciatis obcaecati soluta illo, voluptatem labore numquam, deleniti aliquid.</p>

                          <div class="input-estudio">
                            <input type="file" class="input-file-estudio">
                          </div>  
                          
                        </div>
                    </div>

                    <div class="box-card">
                        <div class="box-header">
                          <div class="fecha">
                            <p>17/07/2017</p>
                          </div>
                          <div class="especialista">
                            <p>Especialidad : Especialista</p>
                          </div>
                        </div>

                        <div class="box-body">
                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque sequi molestiae possimus adipisci dignissimos consectetur laboriosam, quidem, illum nobis. Facilis repellendus perspiciatis obcaecati soluta illo, voluptatem labore numquam, deleniti aliquid.</p>

                          <div class="input-estudio">
                            <input type="file" class="input-file-estudio">
                          </div>

                        </div>
                    </div>
                </article>
                <article id="tab4">
                    <h1 class="title-clinico ">Antecedentes</h1>
                    
                    <div class="box-card box-antecedente">

                        <div class="box-header header-antecedente">
                          <div class="ops-ant">
                            <i class="fa fa-bars" aria-hidden="true"></i>Familiares
                          </div>
                          <i class="fa fa-bars icon-antecedentes" aria-hidden="true"></i>
                        </div>

                        <div class="box-body body-antecedentes">
                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque sequi molestiae possimus adipisci dignissimos consectetur laboriosam, quidem, illum nobis. Facilis repellendus perspiciatis obcaecati soluta illo, voluptatem labore numquam, deleniti aliquid.</p>

                          <div class="input-estudio">
                            <input type="file" class="input-file-estudio">
                          </div>

                        </div>
                    </div>
                </article>
          </div>


       </div>




</div>


</body>
</html>