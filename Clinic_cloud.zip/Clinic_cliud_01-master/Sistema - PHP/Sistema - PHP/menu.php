
<nav class="menu" id="menu">
        <section class="logo">
            <img src="img/logotipo.png" alt="">
            <a href="ajustes_perfil.php"><i  class="fa fa-cog" id="rotacion" aria-hidden="true"></i></a>
        </section>

        <section class="info-img">
            <div class="img">
                <img src="img/photo_perfil/<?php echo($_SESSION["id_usuario"]) ?>.jpg" alt="">
            </div>  
            <p><?php echo strtoupper($_SESSION["nombre"])." ".strtoupper($_SESSION["apellido"]); 


            ?></p>
        </section>

        <ul class="accordion-menu ">
        <!--
          <li>
              <a href="">
                <div class="dropdownlink"><i class="fa fa-home" aria-hidden="true"></i> <span style="color: #fff">Inicio</span>
                <i class="fa fa-chevron-down" aria-hidden="true"></i></div> 
              </a>
          </li>
         -->
          <li>
            <a href="paciente.php">
              <div class="dropdownlink"><i class="fa fa-users" aria-hidden="true"></i> <span style="color: #fff">Pacientes</span>
              <i class="fa fa-chevron-down" aria-hidden="true"></i></div>
            </a>
          </li>
          <li>
            <a href="turnos_redux.php">
              <div class="dropdownlink"><i class="fa fa-calendar-alt" aria-hidden="true"></i><span style="color: #fff">Turnos</span>
              <i class="fa fa-chevron-down" aria-hidden="true"></i></div>
            </a>
          </li>
          <?php 
            if ($_SESSION["nivel_usuario"]=="0"){
              echo " <li>
                      <a href='reportes.php'>
                        <div class='dropdownlink'><i class='fa fa-clipboard-list' aria-hidden='true'></i><span style='color: #fff'>Reportes</span>
                        <i class='fa fa-chevron-down' aria-hidden='true'></i></div>
                      </a>
                    </li>";
              echo " <li>
                    <a href='administracion.php'>
                       <div class='dropdownlink'><i class='fa fa-unlock' aria-hidden='true'></i><span style='color: #fff'>Administracion</span>
                        <i class='fa fa-chevron-down' aria-hidden='true'></i></div>
                    </a>
                    </li>";
              }else{
                if ($_SESSION["nivel_usuario"]=="2") {
                   echo " <li>
                      <a href='reportes.php'>
                        <div class='dropdownlink'><i class='fa fa-clipboard-list' aria-hidden='true'></i><span style='color: #fff'>Reportes</span>
                        <i class='fa fa-chevron-down' aria-hidden='true'></i></div>
                      </a>
                    </li>";
                }
              }
           ?>
         
         
        </ul>
<a href="cerrar_sesion.php">
        <div class="cerrar-sesion">
         <p>Cerrar sesion</p>
        </div>
</a>
  </nav>  