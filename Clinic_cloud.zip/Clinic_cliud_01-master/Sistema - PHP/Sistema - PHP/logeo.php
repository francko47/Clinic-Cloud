<?php 
$path_css="css/";
$path_js="";
 ?>
<!-- CONECCION A LA BASE DE DATOS -->
  <?php 
include "funciones/conecxion.php";
if (!$conn=conn_Star()) {
    header("location:error.php");
  }
  ?>
<!-- VALIDAR LOGEO -->
<?php 
  session_start();
  if (isset($_SESSION["nombre"])){
     header("Location:paciente.php");
  }
 ?>

  <?php 

  if (isset($_GET["nombre"])) {
        $nombre=$_GET["nombre"];
        $pass=$_GET["pass"];
       if( $resultado=validar_usuario($nombre,$pass,$conn)){
            $fila = mysqli_fetch_row($resultado);
             $_SESSION["id_usuario"]=$fila[0];
             $_SESSION["nombre"]=$fila[1];
             $_SESSION["apellido"]=$fila[2];
             $_SESSION["especialidad"]=$fila[4];
             $_SESSION["nivel_usuario"]=$fila[5];
             $mostrar=$_SESSION["id_usuario"].$_SESSION["nombre"].$_SESSION["apellido"].$_SESSION["especialidad"].$_SESSION["nivel_usuario"];
               header("Location:paciente.php");
       }else{
        // header("location:no.php");
       } 
    }  
   ?>
 <html>
    <head>
        <meta charset="utf-8">
        <?php include "funciones/header.html" ?>
        <title>Form 1</title>
        <link href="https://fonts.googleapis.com/css?family=Ubuntu+Mono" rel="stylesheet">
            <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">

        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >
        <link rel="stylesheet" href="<?php echo $path_css;?>estilos.css" />
        <link rel="stylesheet" type="text/css" href="css/font.css">
    </head>
    <body>
        <div class="form-box">
            <section class="left-box die400">
            	<div class="text-login">
            		<span>Bienvenido!</span>
             	   <h5>Creado por: nuestros nombres i/o fotos</h5>
            	</div>
            </section>
            <section class="right-box">
                <span>Ingresar</span>
                <form action="logeo.php" method="GET">
                	<div class="input-login">
                		<!--name input-->
                		<i class="fa fa-user" aria-hidden="true"></i>
                  	   <input type="text" placeholder="Name"/ name="nombre" required pattern="[A-Za-z0-9]{2,10}">
                	</div> 
                    <div class="input-login" style="margin-top: 50px;">
                    	 <!--password input-->
                    	<i class="fa fa-unlock" aria-hidden="true"></i>
                    	<input type="password" name="pass" placeholder="Password"/ required pattern="[A-Za-z0-9]{2,10}">
                    </div>
                    <input type="submit" name="btn" value="Ingresar" class="btn_log">
                  <?php //echo $mostrar; ?>
                </form>
            </section>
        </div>
    </body>
</html>