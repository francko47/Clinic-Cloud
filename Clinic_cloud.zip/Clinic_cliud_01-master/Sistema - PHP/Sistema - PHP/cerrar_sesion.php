
<?php 
  session_start();
  if (!isset($_SESSION["nombre"])){
    header("location:error.php");
  }

  session_destroy();
  header("Location:logeo.php");
 ?>