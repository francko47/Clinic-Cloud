   function declare_xmlhttp(){
   	var xmlhttp;
		if (window.XMLHttpRequest) {
			xmlhttp=new XMLHttpRequest();
		}else{
			xmlhttp=new ActiveXObject("microsoft.XMLHTTP");
		}
   	return xmlhttp;
   }
//////////////////////////////////////////////////////////////////////////////
//__ TURNOS REPORTE _____________________________________________________________
	function reporte_diario(){
			var xmlhttp=declare_xmlhttp();
				var especialista=document.getElementById("esp").value;

				var res12=document.getElementById("res_listado");
				xmlhttp.onreadystatechange=function(){

						if (this.readyState===4 && this.status===200) {
							 	 res12.innerHTML=this.responseText;
						}
					}
					


				xmlhttp.open("GET","funciones/ajax_turnos_redux.php?listar="+especialista,true);
				xmlhttp.send();


	}

//_______________________---------------------------------------______________________________
//_______________________ REPORTES DE PACIENTES QUE NO VINIERON ______________________________
//_______________________---------------------------------------______________________________

	function R_PQNA(id){
		alert(id);
		//var
		var desde=document.getElementById('desde').value;
		var res=document.getElementById('listar_RPQNA');
		var xmlhttp=declare_xmlhttp();

		//listar_RPQNA
		alert(desde);
		xmlhttp.onreadystatechange=function(){
				if (this.readyState===4 && this.status===200) {
					res.innerHTML=this.responseText;
				}
		}

		xmlhttp.open("GET","funciones/ajax_reportes.php?R2="+id+"&desde="+desde,true);
		xmlhttp.send();


	}











