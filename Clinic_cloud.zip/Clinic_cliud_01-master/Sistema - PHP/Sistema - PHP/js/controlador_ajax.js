   function declare_xmlhttp(){
   	var xmlhttp;
		if (window.XMLHttpRequest) {
			xmlhttp=new XMLHttpRequest();
		}else{
			xmlhttp=new ActiveXObject("microsoft.XMLHTTP");
		}
   	return xmlhttp;
   }

//PACIENTES____________________________________________________________________



	function mostrar_preguntas(id_paciente){
		var xmlhttp=declare_xmlhttp();
		//end variables
		var resultado=fomulario_paciente;
		var res_array=[resultado.dni,
						resultado.nombre,
						resultado.apellido,
						resultado.direccion,
						resultado.sexo,
						resultado.fech_nacimiento,
						resultado.telefono,
						resultado.celular,
						resultado.obra_social,
						resultado.n_afiliado,
						resultado.estado];

	//end variables
					var caracter="", cadena="";
					var y=0, p=0;
		//alert(res_array[2]);
			xmlhttp.onreadystatechange=function(){

				if (this.readyState===4 && this.status===200) {
					var res=this.responseText;
				//	alert(res);				
					var largo=res.length;					
					for (var i =0; i <= largo-2; i++) {	
						caracter=res.substring(i, i+1);
						if(caracter.toString()==","){
							cadena=res.substring(y, i);
							//alert("cadena: "+cadena);
							y=i+1;
							//alert("res_array: "+res_array[p]);
							res_array[p++].value=cadena;
						}
	
					}
					
				}
			}
			
		xmlhttp.open("GET","funciones/ajax_pacientes.php?id_paciente="+id_paciente,true);
		xmlhttp.send();
	}

	function mostrar_pregunta(dato){
		//alert("datoss");

		var datos=form_filtrar_pacientes.dni_filtrar;
		//alert(datos);
		var datoss=datos.value;
		//alert(datoss);
		if (datoss.length>3){
		//alert(dato);

			var xmlhttp=declare_xmlhttp();
				//end variables
				var dato=form_filtrar_pacientes;
				var listado_pacientes=document.getElementById("listado_pacientes");
								

				//end variables

					xmlhttp.onreadystatechange=function(){

						if (this.readyState===4 && this.status===200) {
					//		 alert(this.responseText);
							 listado_pacientes.innerHTML=this.responseText;
							
						}
				}
					
				xmlhttp.open("GET","funciones/ajax_pacientes.php?listar="+datoss,true);
				xmlhttp.send();






		}
	
	}

	
	function mostrar_historial(id_paciente){
		//variables
		var	res_historial_p=document.getElementById("res_historia");
		//end variables
		var xmlhttp=declare_xmlhttp();
			xmlhttp.onreadystatechange=function(){

				if (this.readyState===4 && this.status===200) {
					 res_historial_p.innerHTML=this.responseText;
					 acordion();											
				}
			}
			
		xmlhttp.open("GET","funciones/ajax_pacientes.php?id_pacientes="+id_paciente,true);
		xmlhttp.send();
	}

	function holamundo(id_paciente){
			//variables
			alert(id_paciente);
			var p_opcion=document.getElementById("p_opciones");
			//end variables
			alert(p_opcion);
			var xmlhttp=declare_xmlhttp();
				xmlhttp.onreadystatechange=function(){

					if (this.readyState===4 && this.status===200) {
						 p_opcion.innerHTML=this.responseText;
					}
				}
				
			xmlhttp.open("GET","funciones/ajax_pacientes.php?p_opciones="+id_paciente,true);
			xmlhttp.send();
	}	

//END PACIENTES____________________________________________________________
////////////////////////////////////////////////////////////////////////////
//AGREGAR CONSULTA________________________________________________________

		
				
			
		function mostrar_historial_consultas(id_paciente){
			var res_historial_ag_consulta=document.getElementById("h_ag_paciente");
			var xmlhttp=declare_xmlhttp();
				xmlhttp.onreadystatechange=function(){

					if (this.readyState===4 && this.status===200) {
					//	alert(res_historial_ag_consulta);
					//	alert(this.responseText);
						 res_historial_ag_consulta.innerHTML=this.responseText;
					//	 alert(this.responseText);
						 		acordion();								
					}
				}
				
			xmlhttp.open("GET","funciones/ajax_agregar_consulta.php?id_pacientes="+id_paciente,true);
			xmlhttp.send();
	}
	
//END AGREGAR CONSULTA________________________________________________________
//////////////////////////////////////////////////////////////////////////////
//OBRAS SOCIALES_______________________________________________________________

function mostrar_datos(id_obra){
	var xmlhttp=declare_xmlhttp();
	var form_obss=formu;

	var res_array=[form_obss.id_ob,
						form_obss.nombre_obsocial,
						form_obss.Coopago];

	var caracter="", cadena="";
	var y=0, p=0;
	xmlhttp.onreadystatechange=function(){

			if (this.readyState===4 && this.status===200) {
					var res=this.responseText;
					var largo=res.length;					
					for (var i =0; i <= largo-1; i++) {	
						caracter=res.substring(i, i+1);
						if(caracter.toString()==","){
							cadena=res.substring(y, i);
					//		alert("cadena: "+cadena);
							y=i+1;
							//alert("res_array: "+res_array[p]);
							res_array[p++].value=cadena;
						}
	
					}
				
			}
	}
		
	xmlhttp.open("GET","funciones/ajax_obsocial.php?obsocial="+id_obra,true);
	xmlhttp.send();
}

function estado_ob_social_m(estado){

			var xmlhttp=declare_xmlhttp();
			var res=document.getElementById("estado_ObSo_M");
				xmlhttp.onreadystatechange=function(){

					if (this.readyState===4 && this.status===200) {
						res.innerHTML=this.responseText;

					}
				}
				
			xmlhttp.open("GET","funciones/ajax_obsocial.php?estado="+estado,true);
			xmlhttp.send();
	}

//END OBRAS SOCIALES________________________________________________________
//////////////////////////////////////////////////////////////////////////////
//__AJUSTE DE PERFIL_____________________________________________________________

	function eliminar_ob_es_l(id_ob,id){
			var xmlhttp=declare_xmlhttp();
				xmlhttp.onreadystatechange=function(){
					if (this.readyState===4 && this.status===200) {
					//	alert(this.responseText);
					}
				}
			xmlhttp.open("GET","funciones/ajax_ajuste_perfil.php?eliminar_ob="+id_ob+"&id_es="+id,true);
			xmlhttp.send();
	}
	function agregar_ob_es_l(id){
		var id_ob_nueva=document.getElementById("ob_social");
		//alert(id_ob_nueva.value+" "+id);
			var xmlhttp=declare_xmlhttp();
				xmlhttp.onreadystatechange=function(){
					if (this.readyState===4 && this.status===200) {
					//	alert(this.responseText);
						document.getElementById("mostrar_ob_espe").innerHTML=this.responseText;
					}
				}
			xmlhttp.open("GET","funciones/ajax_ajuste_perfil.php?agregar_ob="+id_ob_nueva.value+"&id_es="+id,true);
			xmlhttp.send();
	}
	

	function Listar_ob_es_2(id_especialista){

			var xmlhttp=declare_xmlhttp();
			var ob_1=document.getElementById("form_ag_ob_es");
				xmlhttp.onreadystatechange=function(){

					if (this.readyState===4 && this.status===200) {
						 ob_1.innerHTML=this.responseText;
					//	 alert(this.responseText);

					}
				}
				
			xmlhttp.open("GET","funciones/ajax_ajuste_perfil.php?listar_ob_1="+id_especialista,true);
			xmlhttp.send();
	}

	function Listar_ob_es_1(id_especialista){

			var xmlhttp=declare_xmlhttp();
			var ob_2=document.getElementById("mostrar_ob_espe");
				xmlhttp.onreadystatechange=function(){

					if (this.readyState===4 && this.status===200) {
						 ob_2.innerHTML=this.responseText;
					//	 alert(this.responseText);

					}
				}
				
			xmlhttp.open("GET","funciones/ajax_ajuste_perfil.php?listar_ob_2="+id_especialista,true);
			xmlhttp.send();
	}

	function Listar_ob_es_0(id_especialista){
			alert("cargado con exito");
			Listar_ob_es_2(id_especialista);
			Listar_ob_es_1(id_especialista);
	}

	

//END AJUSTE DE PERFIL ________________________________________________________
//////////////////////////////////////////////////////////////////////////////
//__ TURNOS_____________________________________________________________

function auto_completado_turnos(dni){
			var xmlhttp=declare_xmlhttp();
			var form=fomr_ajuste_1;

			var res_array=[form.nombre,
							form.apellido,
							form.txtID_paciente
						];
								res_array[0].value="";
								res_array[1].value="";
								res_array[2].value="";

					//res_array[1]="";
						//end variables
				var caracter="", cadena="";
				var y=0, p=0;
				xmlhttp.onreadystatechange=function(){

					if (this.readyState===4 && this.status===200) {
						 	var res=this.responseText;
								var largo=res.length;		

								for (var i =0; i <= largo-2; i++) {	
									caracter=res.substring(i, i+1);

									if(caracter.toString()==","){
										cadena=res.substring(y, i);
										y=i+1;
										res_array[p++].value=cadena;
									}
				
								}
			
					

					}
				}
				
			xmlhttp.open("GET","funciones/ajax_turnos.php?buscar="+dni,true);
			xmlhttp.send();
	}



//END TURNOS ________________________________________________________
//////////////////////////////////////////////////////////////////////////////
//__ USUARIO _____________________________________________________________

	function rellenar_f_u_m(usuario){
				var xmlhttp=declare_xmlhttp();
				var form=form_m_usuario;
				var res_array=[form.id_usuario,
								form.dni,
								form.nombre,
								form.apellido,
								form.pass
							];
							//end variables
					var caracter="", cadena="";
					var y=0, p=0;
					xmlhttp.onreadystatechange=function(){

						if (this.readyState===4 && this.status===200) {
							 	var res=this.responseText;
								var largo=res.length;					
								for (var i =0; i <= largo-2; i++) {	
									caracter=res.substring(i, i+1);
									if(caracter.toString()==","){
										cadena=res.substring(y, i);
										y=i+1;
										res_array[p++].value=cadena;
									}
				
								}
						

						}
					}
					
				xmlhttp.open("GET","funciones/ajax_usuario.php?usuario="+usuario,true);
				xmlhttp.send();
	}


		function rellenar_f_u_m_sexo(usuario){
				var xmlhttp=declare_xmlhttp();
				var res=document.getElementById("sexo_usuario");
				xmlhttp.onreadystatechange=function(){

						if (this.readyState===4 && this.status===200) {
							 	 res.innerHTML=this.responseText;
					
						}
					}
					
				xmlhttp.open("GET","funciones/ajax_usuario.php?sexo="+usuario,true);
				xmlhttp.send();
	}


	function rellenar_f_u_m_tipo(usuario){
				var xmlhttp=declare_xmlhttp();
				var res=document.getElementById("tipo_usuario");
				xmlhttp.onreadystatechange=function(){

						if (this.readyState===4 && this.status===200) {
							 	 res.innerHTML=this.responseText;
						}
					}
					
				xmlhttp.open("GET","funciones/ajax_usuario.php?tipo="+usuario,true);
				xmlhttp.send();
	}

	function usuario_modificar_0(usuario){
				Abrir_M_usu();
				rellenar_f_u_m(usuario);
				rellenar_f_u_m_sexo(usuario);
				rellenar_f_u_m_tipo(usuario);

	}


//END USUARIO ________________________________________________________
//////////////////////////////////////////////////////////////////////////////
