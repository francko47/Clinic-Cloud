   function declare_xmlhttp(){
   	var xmlhttp;
		if (window.XMLHttpRequest) {
			xmlhttp=new XMLHttpRequest();
		}else{
			xmlhttp=new ActiveXObject("microsoft.XMLHTTP");
		}
   	return xmlhttp;
   }
//////////////////////////////////////////////////////////////////////////////
//__ TURNOS REDUX _____________________________________________________________
	function listar_turno_redux_load(){
			var xmlhttp=declare_xmlhttp();
				var especialista=document.getElementById("esp").value;

				var res12=document.getElementById("res_listado");
				xmlhttp.onreadystatechange=function(){

						if (this.readyState===4 && this.status===200) {
							 	 res12.innerHTML=this.responseText;
						}
					}
					


				xmlhttp.open("GET","funciones/ajax_turnos_redux.php?listar="+especialista,true);
				xmlhttp.send();


	}

	function listar_turno_redux(especialista){
			var xmlhttp=declare_xmlhttp();
				var especialista=document.getElementById("esp").value;

				var res12=document.getElementById("res_listado");
				xmlhttp.onreadystatechange=function(){

						if (this.readyState===4 && this.status===200) {
							 	 res12.innerHTML=this.responseText;
						}
					}
					


				xmlhttp.open("GET","funciones/ajax_turnos_redux.php?listar="+especialista,true);
				xmlhttp.send();


	}

function listar_turno_redux_dia(dia){
			var xmlhttp=declare_xmlhttp();
				var especialista=document.getElementById("esp").value;
				var res12=document.getElementById("res_listado");
				xmlhttp.onreadystatechange=function(){

						if (this.readyState===4 && this.status===200) {
							 	 res12.innerHTML=this.responseText;
						}
					}
					


				xmlhttp.open("GET","funciones/ajax_turnos_redux.php?listar="+especialista+"&dia="+dia,true);
				xmlhttp.send();
}
	function ag_turno_redux(form_n){
		var xmlhttp=declare_xmlhttp();

				var esp=document.getElementById("esp").value;
				var fecha=document.getElementById("año").value;
				var id_p=document.getElementById("id_"+form_n).value;
				var hs_p=document.getElementById("hs_"+form_n).value;
				var min_p=document.getElementById("min_"+form_n).value;
				if (id_p=="") {
					alert("complete todos los campos antes de agregar un turno");
				}else{
					xmlhttp.onreadystatechange=function(){
						if (this.readyState===4 && this.status===200) {
							alert("guardado correctamente");
						}
					}
					
					xmlhttp.open("GET","funciones/ajax_turnos_redux.php?agregar="+id_p+"&esp="+esp+"&hs="+hs_p+"&min="+min_p+"&fecha="+fecha,true);
					xmlhttp.send();
				}
	}
	function ir_turno_redux(form_n){
		window.location="agregar_consulta.php?id_paciente="+form_n;
	}

	function buscar_paciente_t_reduxs(dni_p,input_n)
	{

		var dni = document.getElementById("dni_"+input_n);
		var xmlhttp=declare_xmlhttp();
				var nomyape=document.getElementById("nombre_"+input_n);

				var id_p=document.getElementById("id_"+input_n);
				var telefono=document.getElementById("telefono_"+input_n);
				var obra_social=document.getElementById("obra_social_"+input_n);
				var n_carnet=document.getElementById("n_carnet_"+input_n);
				var copago=document.getElementById("coopago_"+input_n);
				var res_array=[nomyape,id_p,telefono,obra_social,n_carnet,copago];
				var caracter="", cadena="";

				res_array[0].value="";
				res_array[1].value="";
				res_array[2].value="";
				res_array[3].value="";

				res_array[4].value="";
				res_array[5].value="";
					var y=0, p=0;

			//alert(res_array[2]);
				xmlhttp.onreadystatechange=function(){

					if (this.readyState===4 && this.status===200) {
						var res=this.responseText;
						//alert(res);				
						var largo=res.length;					
						for (var i =0; i <= largo-2; i++) {	
							caracter=res.substring(i, i+1);
							if(caracter.toString()==","){
								cadena=res.substring(y, i);
								y=i+1;
								res_array[p++].value=cadena;
							}
		
						}
						//alert(res_array[1].value);
					}

				}
				xmlhttp.open("GET","funciones/ajax_turnos_redux.php?buscar="+dni_p,true);
				xmlhttp.send();
	}


	function cambiar_estado_turno(valor,paci,hs,mn){
		var xmlhttp=declare_xmlhttp();
		var fecha=document.getElementById("año").value;
		var es=document.getElementById("esp").value;
		xmlhttp.onreadystatechange=function(){

					if (this.readyState===4 && this.status===200) {
						//alert(this.responseText);
					}

				}
				xmlhttp.open("GET","funciones/ajax_turnos_redux.php?estado_turno="+valor+"&paci="+paci+"&esp="+es+"&hs="+hs+"&min="+mn+"&fecha="+fecha,true);
				xmlhttp.send();

	}


	function cambiar_pago(valor,paci,hs,mn){
		var xmlhttp=declare_xmlhttp();
		var fecha=document.getElementById("año").value;
		var es=document.getElementById("esp").value;
		xmlhttp.onreadystatechange=function(){
					if (this.readyState===4 && this.status===200) {
						//alert(this.responseText);
					}

				}
				xmlhttp.open("GET","funciones/ajax_turnos_redux.php?cambiar_pago="+valor+"&paci="+paci+"&esp="+es+"&hs="+hs+"&min="+mn+"&fecha="+fecha,true);
				xmlhttp.send();

	}