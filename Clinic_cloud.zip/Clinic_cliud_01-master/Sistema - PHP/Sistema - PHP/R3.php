<?php 
$path_css="css/";
$path_js="";
 ?>

   <!-- CONECCION A LA BASE DE DATOS -->
  <?php 
include "funciones/conecxion.php";
include "funciones/f_R1.php";

if (!$conn=conn_Star()) {
    header("location:error.php");
  }
  ?>
<!-- VALIDAR LOGEO -->
<?php 
  session_start();
  if (!isset($_SESSION["nombre"])){
     header("Location:logeo.php");
  }
 ?>
 <!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
        <?php include "funciones/header.html" ?>


    <link href="https://fonts.googleapis.com/css?family=Roboto:300" rel="stylesheet">

		
		<link rel="stylesheet" type="text/css" href="<?php echo $path_css;?>estilos_generales.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo $path_css;?>estilos_R2.css" />


	<script type="text/javascript" src="jquery-3.3.1.min.js"></script>

	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >

	<script>
       function Mostrar() {
            document.getElementById("menu").style.display = "block";
            document.getElementById("cuerpo").style.marginLeft = "230px";
        }

        function Ocultar() {
            document.getElementById("menu").style.display = "none";
            document.getElementById("cuerpo").style.marginLeft = "0px";
        }

        function Mostrar_Ocultar() {
          var menu=document.getElementById("menu");

          if (menu.style.display=="none") {
            Mostrar();
          }else{
            Ocultar();
          }
        }
    </script>

</head>
<body>


<div class="container">

  <?php include "menu.php"; ?>      
	      

    <section class="cuerpo" id="cuerpo">
    	<h2> 
    		<a id="abrir" class="abrir-cerrar" href="javascript:void(0)" onclick="Mostrar_Ocultar()">
              <div class="abrir-menu"><i class="fas fa-align-justify"></i></div>
          </a>

         	Reportes

    		<img  class="logo-responsive" src="img/logo.png" alt="">
    	</h2>

      
            <div id="main-container">

        <form>

          <div class="content-fecha">
            <div class="fecha">
                Fecha:
               <input type='date'/>
            </div>

            <div class="btn-hoy">Hoy: <input type="checkbox" name=""></div>
<!--
            <div class="fecha">
                Hasta:
              <input type='date'/>
            </div>
-->
          </div>
          <div class="content-btn">
            <div class="btn-plantilla btn-excel">Descargar EXCEL</div>
            <div class="btn-plantilla btn-pdf">Descargar PDF</div>
          </div>

        </form>

        <div class="table-reporte-container">
          <table>
            <thead>
              <tr>
                <th>Paciente</th><th>DNI</th><th>Obra Social</th><th>N° Carnet</th><th>Afiliacion</th>
              </tr>
            </thead>
              <?php echo listar_RDPP($conn,$_SESSION['id_usuario']); ?>

            <tr>
             <td>Roberto Carlos</td><td>42567891</td><td>OSDE</td><td>00112425445</td><td>Valido</td>
            <tr>
             <td>Roberto Carlos</td><td>42567891</td><td>OSDE</td><td>00112425445</td><td>Valido</td>
            </tr>

            <tr>
              <td>Roberto Carlos</td><td>42567891</td><td>OSDE</td><td>00112425445</td><td>Valido</td>
            </tr>

            <?php 
              //echo Listar_Uusuarios($conn);
             ?>
          </table>
        </div>
     </div>
     

    </section>




</div>





<scripst src="js/jquery.min.js"></scripst>

	
</body>
</html>