<?php 
  $path_css="css/";
  $path_js="js_p/";
 ?>
  <!-- CONECCION A LA BASE DE DATOS -->
  <?php 
  include "funciones/conecxion.php";
  include "funciones/f_turnos_redux.php";

  if (!$conn=conn_Star())
    header("location:error.php");
  ?>
<!-- VALIDAR LOGEO -->
<?php 
  session_start();
  if (!isset($_SESSION["nombre"])){
     header("Location:logeo.php");
  }
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
   <!--carga de archivos css-->
   <!--     -->  
   <link rel="stylesheet" href="<?php echo $path_css;?>estilos_generales.css">
   <link rel="stylesheet" href="<?php echo $path_css;?>estilos_turnos_redux.css">
   
        <?php include "funciones/header.html" ?>

   <link href="https://fonts.googleapis.com/css?family=Roboto:300" rel="stylesheet">

  <script type="text/javascript" src="jquery-3.3.1.min.js"></script>

  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >
  <link rel="stylesheet" type="text/css" href="css/font.css">
    <meta charset="UTF-8">
    <title>Turnos</title>

    
  

  <script>
       function Mostrar() {
            document.getElementById("menu").style.display = "block";
            document.getElementById("cuerpo").style.marginLeft = "230px";
        }

        function Ocultar() {
            document.getElementById("menu").style.display = "none";
            document.getElementById("cuerpo").style.marginLeft = "0px";
            document.getElementById("tam_encabezado").style.width = "13.7%";
        }

        function Mostrar_Ocultar() {
          var menu=document.getElementById("menu");

          if (menu.style.display=="none") {
            Mostrar();
          }else{
            Ocultar();
          }
        }

     $( function() {
          $( "#año" ).datepicker();
        } );
    </script>
</head>
<body onload="listar_turno_redux_load()">
  <?php 
    include "menu.php";
  ?>
    <a data-toggle="collapse" onclick="mostrar()" href="#menu" aria-expanded="false" aria-controls="menu">
    </a>
    
    <section class="cuerpo" id="cuerpo">
        
 
    <h2> 
          <a id="abrir" class="abrir-cerrar" href="javascript:void(0)" onclick="Mostrar_Ocultar()">
              <div class="abrir-menu"><i class="fas fa-align-justify"></i></div>
          </a>
          Turnos agus
        <img  class="logo-responsive" src="img/logo.png" alt="">
    </h2>
    <div id="main-container">
      <?php 
        if ($_SESSION["nivel_usuario"]==2) {
          echo listar_especialista_t_1($conn,$_SESSION["id_usuario"]);
        }else{
          echo listar_especialista_t($conn);
          echo "<button type='button' class='btn-agregar-paciente' onclick='altapacientes()'>Agregar nuevo paciente
            </button> ";
        }
      ?>


        <div class="tabla_reportes">
          <div id="res_listado"></div>
        </div>
    </div>
    </section>



</div>
<script src="js/controlador_turnos_resux.js"></script>
<script src="js/controlador_turnos_redux.js"></script>
<script src="js_p/turnos.js"></script>
</body>
</html>