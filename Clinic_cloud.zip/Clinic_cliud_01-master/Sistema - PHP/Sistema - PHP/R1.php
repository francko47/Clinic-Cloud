<?php 
$path_css="css/";
$path_js="";
 ?>

   <!-- CONECCION A LA BASE DE DATOS -->
  <?php 
include "funciones/conecxion.php";
include "funciones/f_R1.php";
if (!$conn=conn_Star()) {
    header("location:error.php");
  }
  ?>
<!-- VALIDAR LOGEO -->
<?php 
  session_start();
  if (!isset($_SESSION["nombre"])){
     header("Location:logeo.php");
  }
 ?>
 <!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
        <?php include "funciones/header.html" ?>


    <link href="https://fonts.googleapis.com/css?family=Roboto:300" rel="stylesheet">

		
		<link rel="stylesheet" type="text/css" href="<?php echo $path_css;?>estilos_generales.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo $path_css;?>estilos_R1.css" />


	<script type="text/javascript" src="jquery-3.3.1.min.js"></script>

	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >

	<script>
       function Mostrar() {
            document.getElementById("menu").style.display = "block";
            document.getElementById("cuerpo").style.marginLeft = "230px";
        }

        function Ocultar() {
            document.getElementById("menu").style.display = "none";
            document.getElementById("cuerpo").style.marginLeft = "0px";
        }

        function Mostrar_Ocultar() {
          var menu=document.getElementById("menu");

          if (menu.style.display=="none") {
            Mostrar();
          }else{
            Ocultar();
          }
        }
    </script>

</head>
<body>


<div class="container">

  <?php include "menu.php"; ?>      
	      

    <section class="cuerpo" id="cuerpo">
    	<h2> 
    		<a id="abrir" class="abrir-cerrar" href="javascript:void(0)" onclick="Mostrar_Ocultar()">
              <div class="abrir-menu"><i class="fas fa-align-justify"></i></div>
          </a>

         	Reportes

    		<img  class="logo-responsive" src="img/logo.png" alt="">
    	</h2>

      
      <div id="main-container">

        
           
          <?php 
            if ($_SESSION["nivel_usuario"]==0)
              echo lstar_espcialista($conn,$_SESSION['id_usuario']);
            else
              echo espcialista($conn,$_SESSION['id_usuario']);
          ?>
        
       
        <div class="btn-plantilla btn-excel">Descargar EXCEL</div>
       <a href="R1_pdf.php" target="_blank"> <div class="btn-plantilla btn-pdf">Descargar PDF</div></a>

        <div class="table-reporte-container">
          <table>
            <thead>
              <tr>
                <th>Paciente</th><th>Obra Social</th><th>OB Bruto</th><th>Desc. CMP + Impuestos</th><th>OB Neto</th><th>Coopago (Abonado en Efectivo)</th><th>OB + Coopago (Bruto)</th><th>Alq. Consultorio</th><th>Liq. 1° sem. mes sig.</th><th>Total a Percibir (Profecional)</th>
              </tr>
            </thead>
            <div id="reporte_1">
              <?php echo listar_RDPP($conn,$_SESSION['id_usuario']); ?>
            </div>
          </table>
        </div>

     </div>
     


<!--
1) Reporte diario por profesional. (Pacientes atendidos, con los montos y obra sociales)
2) Reportes de pacientes que no vienen por intervalo de tiempo.
3)Reporte contable diario 
4)cantidad de pacientes atendidos por obra social.
5) cantidad de turnos tomados por cada recepcionista 
  --> 
    </section>




</div>





<scripst src="js/jquery.min.js"></scripst>
<scripst src="js/controlador_reportes.js"></scripst>

	
</body>
</html>