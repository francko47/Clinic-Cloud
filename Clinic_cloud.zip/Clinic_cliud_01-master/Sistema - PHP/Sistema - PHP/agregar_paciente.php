<?php 
$path_css="css/";
$path_js="";
$path_php="funciones/";
 ?>

  <!-- CONECCION A LA BASE DE DATOS -->
  <?php 
include "funciones/conecxion.php";
include "funciones/f_agregar_pacientes.php";
try {
  if (!$conn=conn_Star()) {
    header("location:error.php");
  }

} catch (Exception $e) {
  echo "string";
}
  ?>
<!-- VALIDAR LOGEO -->
<?php 
  session_start();
  if (!isset($_SESSION["nombre"])){
     header("Location:logeo.php");
  }
 ?>


 <?php 
 $ms="";
    if (isset($_GET["btnNewPaciente"])) {
      
      $dni=$_GET["dni"];
      $nombre=$_GET["nombre"];
      $apellido=$_GET["apellido"];
      $fecha_nacimiento=$_GET["fecha_nacimiento"];
      $telefono=$_GET["telefono"];
      $celular=$_GET["celular"];
      $sexo=$_GET["sexo"];

      $nombre_tutor=$_GET["nombre_tutor"];
      $apellido_tutor=$_GET["apellido_tutor"];
      $dni_tutor=$_GET["dni_tutor"];

      $direccion=$_GET["direccion"];
      $localidad=$_GET["localidad"];

      $obra_Social=$_GET["obraSocial"];
      $n_afiliado=$_GET["n_afiliado"];
      $estado=$_GET["estado"];
      $datos_array=array($dni,$nombre,$apellido,$fecha_nacimiento,$telefono,$celular,$sexo, $nombre_tutor,$apellido_tutor,$dni_tutor, $direccion,$localidad, $obra_Social,$n_afiliado,$estado);
       
      if($result=validar_datos_pacientes($conn,$datos_array)){
        $ms=" <script>carter_emergente('agrego'); </script>";
      }
    }
  ?>


  <?php 
  $id_mod="";
      $dni="";
      $nombre="";
      $apellido="";
      $fecha_nacimiento="";
      $telefono="";
      $celular="";
      $sexo="";

      $nombre_tutor="";
      $apellido_tutor="";
      $dni_tutor="";

      $direccion="";
      $localidad="";

      $obra_Social="";
      $n_afiliado="";
      $valido="";


      $h="";
      $m="";

if (isset($_GET["modificar"])) {
  $modificar=true;
  $id_mod="<input type='hidden' name='id_paciente' value='".$_GET["modificar"]."'>";
  $pagina="funciones/modificar_pacientes.php?";
  $btn="Modificar";

  //echo $sqlm;
  if ($resultado=buscar_paciente($_GET["modificar"],$conn)) {
     while ($fila = mysqli_fetch_row($resultado)) {
      $dni=$fila[3];
      $nombre=$fila[1];
      $apellido=$fila[2];
      $fecha_nacimiento=$fila[5];
      $telefono=$fila[4];
      $celular=$fila[9];
      $sexo=$fila[6];

      $nombre_tutor=$fila[11];
      $apellido_tutor=$fila[12];
      $dni_tutor=$fila[13];

      $direccion=$fila[7];
      $localidad=$fila[8];

      $obra_Social=$fila[14];
      $n_afiliado=$fila[16];
      $valido=$fila[17];

      
    
        if ($sexo=="H") {
          $h="selected";
        }else{
          $m="selected";
        }
    }
  }
     
}else{
  $pagina="agregar_paciente.php";
  $modificar=false;
  $btn="Agregar";

}

   ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
        <?php include "funciones/header.html" ?>


   <link href="https://fonts.googleapis.com/css?family=Roboto:300" rel="stylesheet">

  
   <link rel="stylesheet" type="text/css" href="<?php echo $path_css; ?>estilos_generales.css" />
   <link rel="stylesheet" type="text/css" href="<?php echo $path_css; ?>estilos_add_paciente.css" />
   <link rel="stylesheet" type="text/css" href="<?php echo $path_css; ?>estilos_clinico.css" />



  <script type="text/javascript" src="<?php echo $path_js; ?>jquery-3.3.1.min.js"></script>

  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >
  <link rel="stylesheet" type="text/css" href="css/font.css">

  <script>
        function Mostrar() {
            document.getElementById("menu").style.display = "block";
            document.getElementById("cuerpo").style.marginLeft = "230px";
        }

        function Ocultar() {
            document.getElementById("menu").style.display = "none";
            document.getElementById("cuerpo").style.marginLeft = "0px";
        }

        function Mostrar_Ocultar() {
          var menu=document.getElementById("menu");

          if (menu.style.display=="none") {
            Mostrar();
          }else{
            Ocultar();
          }
        }
        carter_emergente('hola');
  </script>
  <script>
    function carter_emergente(ms) {
       alert(ms);
    }

  </script>

</head>
<body>
<?php echo $ms; ?>

<div class="container">

  <?php include "menu.php"; ?>      

    <section class="cuerpo" id="cuerpo">
      <h2> 
        <a id="abrir" class="abrir-cerrar" href="javascript:void(0)" onclick="Mostrar_Ocultar()">
              <div class="abrir-menu"><i class="fas fa-align-justify"></i></div>
          </a>

          <?php if ($modificar) {
            echo "Modificar";
          }else{
            echo "Agregar";
          } 
          ?> Paciente

        <img  class="logo-responsive" src="img/logo.png" alt="">
      </h2>

    
 

   <div class="container-input">

    <form action="<?php echo($pagina); ?>" class="form-add-paciente">
                <?php echo $id_mod; ?>

      <h1 class="title-clinico  title-add"> Datos Personales</h1>

        <div class="input-wrapper obligatorio">
          <input id="input-field" placeholder="Dni" type="text" class="input" name="dni" value="<?php echo($dni) ?>" required>
          <div class="icon-wrapper">
              <span toggle="#input-field" class="fab fa-adn "></span>
          </div>
        </div>

        <div class="input-wrapper obligatorio">
          <input id="input-field" placeholder="Nombre" type="text" class="input" name="nombre" value="<?php echo($nombre) ?>" required>
          <div class="icon-wrapper">
              <span toggle="#input-field" class="fa fa-adn field-icon toggle-input"></span>
          </div>
        </div>

        <div class="input-wrapper obligatorio">
          <input id="input-field" placeholder="Apellido" type="text" class="input" name="apellido" value="<?php echo($apellido) ?>" required>
          <div class="icon-wrapper">
              <span toggle="#input-field" class="fa fa-cog field-icon toggle-input"></span>
          </div>
        </div>

        <div class="input-wrapper obligatorio">
          <input id="input-field" placeholder="Fecha de Nac." type="date" class="input" name="fecha_nacimiento" value="<?php echo($fecha_nacimiento) ?>" required>
          <div class="icon-wrapper">
              <span toggle="#input-field" class="fa fa-cog field-icon toggle-input"></span>
          </div>
        </div>

        <div class="input-wrapper obligatorio">
          <input id="input-field" placeholder="Telefono" type="text" class="input" name="telefono" value="<?php echo($telefono) ?>" required>
          <div class="icon-wrapper">
              <span toggle="#input-field" class="fa fa-cog field-icon toggle-input"></span>
          </div>
        </div>

        <div class="input-wrapper obligatorio">
          <input id="input-field" placeholder="Celular" type="text" class="input" name="celular" value="<?php echo($celular) ?>" required>
          <div class="icon-wrapper">
              <span toggle="#input-field" class="fa fa-cog field-icon toggle-input"></span>
          </div>
        </div>

        <div class="input-wrapper obligatorio" >
            <select id="input-field" class="input" name="sexo" required>
              <option>Sexo</option>
              <option value="H" <?php echo $h;?> >Masculino</option>
              <option value="M" <?php echo $m;?> >Femenino</option>
            </select>
            <div class="icon-wrapper">
                <span toggle="#input-field" class="fa fa-cog field-icon toggle-input"></span>
            </div>
        </div>

        <h1 class="title-clinico title-add "> Datos Familiares (Madre/Padre/Tutor)</h1>

        <div class="input-wrapper">
          <input id="input-field" placeholder="Nombre Tutor" type="text" class="input" name="nombre_tutor" value="<?php echo($nombre_tutor) ?>">
        <div class="icon-wrapper">
              <span toggle="#input-field" class="fa fa-cog field-icon toggle-input"></span>
          </div>
        </div>

         <div class="input-wrapper">
          <input id="input-field" placeholder="Apellido Tutor" type="text" class="input" name="apellido_tutor" value="<?php echo($apellido_tutor) ?>">
          <div class="icon-wrapper">
              <span toggle="#input-field" class="fa fa-cog field-icon toggle-input"></span>
          </div>
        </div>

         <div class="input-wrapper">
          <input id="input-field" placeholder="Dni Tutor" type="text" class="input" name="dni_tutor" value="<?php echo($dni_tutor) ?>">
          <div class="icon-wrapper">
              <span toggle="#input-field" class="fa fa-cog field-icon toggle-input"></span>
          </div>
        </div>


       <h1 class="title-clinico title-add "> Datos Demograficos</h1>

        <div class="input-wrapper">
          <input id="input-field" placeholder="Direccion" type="text" class="input" name="direccion" pattern="[A-Za-z ]{2,16}" value="<?php echo($direccion) ?>">
          <div class="icon-wrapper">
              <span toggle="#input-field" class="fa fa-cog field-icon toggle-input"></span>
          </div>
        </div>

         <div class="input-wrapper">
          <input id="input-field" placeholder="Localidad" type="text" class="input" name="localidad" value="<?php echo($localidad) ?>">
          <div class="icon-wrapper">
              <span toggle="#input-field" class="fa fa-cog field-icon toggle-input"></span>
          </div>
        </div>


          <h1 class="title-clinico title-add"> Datos de la Obra Social</h1>

          <div class="input-wrapper obligatorio" >
            <select id="input-field" type="text" class="input" name="obraSocial" required>
              <option value="1">Particular</option>
                  <?php 
                  if ($modificar){
                    echo obra_Social_m($conn,$_GET["modificar"]);
                  }else{
                     echo obra_Social($conn);
                  }
                  ?>
            </select>
            <div class="icon-wrapper">
                <span toggle="#input-field" class="fa fa-cog field-icon toggle-input"></span>
            </div>
         </div>

          <div class="input-wrapper">
            <input id="input-field" placeholder="N° Afiliado" type="text" class="input" name="n_afiliado" value="<?php echo($n_afiliado) ?>">
            <div class="icon-wrapper">
                <span toggle="#input-field" class="fa fa-cog field-icon toggle-input"></span>
            </div>
          </div>
         
          <div class="input-wrapper" >
            <select id="input-field" class="input" name="estado" required value="<?php echo($estado) ?>">
              <?php 
              if ($modificar){
                echo listar_estados_m($conn,$_GET["modificar"]); 
              }else{
                echo listar_estados($conn); 
              }
              ?>
            </select>
            <div class="icon-wrapper">
              <span toggle="#input-field" class="fa fa-cog field-icon toggle-input"></span>
            </div>
          </div>


            <div class="input-submit-add">
              <input type="submit" class="add-submit" name="btnNewPaciente" value="<?php echo($btn); ?>">
            </div>

      </form>

    </div>

    
    </section>
<br>
<br>
<br>
<br>



</div>





<scripst src="js/jquery.min.js"></scripst>

  
</body>
</html>