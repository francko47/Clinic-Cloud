<?php
header('content-type: application/json');
$pdo=new PDO('mysql:dbname=c_c_santino_01;host=127.0.0.1:3306', 'root','');

$accion= (isset($_GET['accion']))?$_GET['accion']:'leer';

$sentenciaSQL= $pdo->prepare("SELECT * FROM pacientes");
$sentenciaSQL->execute();


$resultado= $sentenciaSQL->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($resultado);