
function control_columna(x){
    alert(document.getElementById("dni_"+x));
    var dni=document.getElementById("dni_"+x);
    if(dni.disabled==true){
        dni.disabled = false;
    }else{
        dni.disabled = true;
    }
}

function control_columna(x){
    alert(document.getElementById("dni_"+x));
    var dni=document.getElementById("dni_"+x);
    if(dni.disabled==true){
        dni.disabled = false;
    }else{
        dni.disabled = true;
    }
}
function altapacientes(){
    var ventana = window.open("agregar_paciente.php", "_blank", "width=700, height=600");
}
