
$('#menu-responsive').click(function(){
	$('.accordion-menu').slideToggle(400);

});