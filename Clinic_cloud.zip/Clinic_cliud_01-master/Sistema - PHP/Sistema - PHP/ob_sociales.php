<?php 
$path_css="css/";
$path_js="";
 ?>

 <!-- CONECCION A LA BASE DE DATOS -->
  <?php 
include "funciones/conecxion.php";
include "funciones/f_obsocial.php";

if (!$conn=conn_Star()) {
    header("location:error.php");
  }
  ?>

<!-- VALIDAR LOGEO -->
<?php 
  session_start();
  if (!isset($_SESSION["nombre"])){
     header("Location:logeo.php");
  }
 ?>

<?php 
if (isset($_GET["eliminar"])) {
      $sql_a="DELETE FROM `c_c_santino_01`.`obra_social` WHERE `id_obra_social`='".$_GET["eliminar"]."';";
    

      if(agregar($sql_a,$conn)){
        header("Location:ob_sociales.php");
      }
    }

 ?>
 <?php 
    if (isset($_POST["btn_AG_OS"])) {

      $nombre_obsocial=$_POST["nombre_obsocial"];
      $Coopago=$_POST["Coopago"];
      $estado=$_POST["estado"];
      $sql_a="INSERT INTO `c_c_santino_01`.`obra_social` (`nombre_obra_soc`, `copago`, `estado`) VALUES ('$nombre_obsocial', '$Coopago','$estado');";

      if(agregar($sql_a,$conn)){
        header("Location:ob_sociales.php");
      }
    }

  ?>
   <?php 
    if (isset($_POST["btn_MO_OS"])) {
      $id_obra=$_POST["id_ob"];
      $nombre_obsocial=$_POST["nombre_obsocial"];
      $Coopago=$_POST["Coopago"];
      $estado=$_POST["estado"];
      $sql_m="UPDATE `c_c_santino_01`.`obra_social` SET `nombre_obra_soc`='".$nombre_obsocial."', `copago`='".$Coopago."', `estado`='".$estado."' WHERE `id_obra_social`='".$id_obra."';";
      if($resu=agregar1($sql_m,$conn)){
        header("Location:ob_sociales.php");
      }else{
        echo "<br>NO AGREGO";
      }
    }

  ?>
 <!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
        <?php include "funciones/header.html" ?>


    <link href="https://fonts.googleapis.com/css?family=Roboto:300" rel="stylesheet">

		
		<link rel="stylesheet" type="text/css" href="<?php echo $path_css;?>estilos_generales.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo $path_css;?>estilos_obsociales.css" />


	<script type="text/javascript" src="jquery-3.3.1.min.js"></script>

	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" >
  <link rel="stylesheet" type="text/css" href="css/font.css">

	<script>
        function Mostrar() {
            document.getElementById("menu").style.display = "block";
            document.getElementById("cuerpo").style.marginLeft = "230px";
        }

        function Ocultar() {
            document.getElementById("menu").style.display = "none";
            document.getElementById("cuerpo").style.marginLeft = "0px";
        }

        function Mostrar_Ocultar() {
          var menu=document.getElementById("menu");

          if (menu.style.display=="none") {
            Mostrar();
          }else{
            Ocultar();
          }
        }


        //MDDAL AGREGAR OBRA SOCIAL
        function Abrir_obsocial() {
            document.getElementById("agregar-obsocial").style.display = "block";
        }

        function Cerrar_obsocial() {
            document.getElementById("agregar-obsocial").style.display = "none";
        }

         //MDDAL AGREGAR OBRA SOCIAL
        function Abrir_M_obsocial() {
            document.getElementById("modificar-obsocial").style.display = "block";
        }

        function Cerrar_M_obsocial() {
            document.getElementById("modificar-obsocial").style.display = "none";
        }
         function hola() {
          alert("holmuncdo");
        }

    </script>

</head>
<body>


<div class="container">

  <?php include "menu.php"; ?>      
	      

    <section class="cuerpo" id="cuerpo">
    	<h2>

    		<a id="abrir" class="abrir-cerrar" href="javascript:void(0)" onclick="Mostrar_Ocultar()">
            	<div class="abrir-menu"><i class="fas fa-align-justify"></i></div>
         	</a>

         	Lista de Obras Sociales

    		<img  class="logo-responsive" src="img/logo.png" alt="">
    	</h2>


     
      <div class="add_social">
       <!-- <a href="javascript:openVentana_add_paciente();" class="agregar">--> 
        <a href="javascript:void(0)" onclick="Abrir_obsocial()"><i class="fa fa-plus"></i> NUEVO OBRA SOCIAL</a>
      </div>



    <div id="main-container">

        <div class="title-table">
          Obras Sociales
        </div>
      <div class="table-sociales-container">
        <table>
          <thead>
            <tr>
              <th>Codigo</th><th>Estado</th><th>Nombre</th><th>Coopago</th><th>Modificar</th>
            </tr>
          </thead>

      <!--    <tr>
            <td>001</td><td>Habilitada</td><td>OSDE</td><td>$120</td><td><i class="fa fa-sync" aria-hidden="true"></i></td>
          </tr>
    -->      <?php 
             echo Listar_Obsociales($conn);
           ?>

        </table>
      </div>
    </div>
 
    </section>




    <div class="modal-add-obsocial" id="agregar-obsocial">
         <div id="registration-form">
          <div class='fieldset'>
            <legend>Ingresar Obra Social  <span href="javascript:void(0)" onclick="Cerrar_obsocial()">X</span></legend>
            <form action="ob_sociales.php" method="post" data-validate="parsley">
              <div class='row'>
                <label for='Nombre'>Nombre</label>
                <input type="text" placeholder="Nombre" name='nombre_obsocial' id='nombre_obsocial' data-required="true" data-error-message="Ingrese Nombre">
              </div>
              <div class='row'>
                <label for="Coopago">Coopago</label>
                <input type="text" placeholder="$ Coopago"  name='Coopago' data-required="true" data-type="Coopago" data-error-message="Ingrese Coopago">
              </div>
              <div class='row' >
                <label for="Estado">Estado</label>
                 <?php echo Listar_estados_ObSo($conn); ?>
              </div>

              <input type="submit" name="btn_AG_OS" value="Ingresar">
            </form>
          </div>
        </div>
    </div>


     <div class="modal-add-obsocial" id="modificar-obsocial">
         <div id="registration-form">
          <div class='fieldset'>
            <legend>Ingresar Obra Social  <span href="javascript:void(0)" onclick="Cerrar_M_obsocial()">X</span></legend>
            <form action="ob_sociales.php" method="post"  name="formu">
                <input type="text" class="ocultar"  name='id_ob'>
              <div class='row'>
                <label for='Nombre'>Nombre</label>
                <input type="text" placeholder="Nombre" name='nombre_obsocial' id='nombre_obsocial' data-required="true" data-error-message="Ingrese Nombre">
              </div>
              <div class='row'>
                <label for="Coopago">Coopago</label>
                <input type="text" placeholder="$ Coopago"  name='Coopago' data-required="true" data-type="Coopago" data-error-message="Ingrese Coopago">
              </div>
              <div class='row' >
                <label for="Estado">Estado</label>
                <select name="estado" id="estado_ObSo_M">
                </select>
              </div>

              <input type="submit" name="btn_MO_OS" value="Modificar">
            </form>
          </div>
        </div>
    </div>

</div>



<script src="js/controlador_ajax.js"></script>


<scripst src="js/jquery.min.js"></scripst>

	
</body>
</html>