<?php 
	$texto="";
	$numero=0;
	$error=$_GET["error"];
	if($error==1){
		$texto="Ocurrio un error con la base de Datos";
		$numero=500;
	}
	if($error==2){
		$texto="Ocurrio un error con la base de Datos";
		$numero=500;
	}
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Error</title>
        <?php include "funciones/header.html" ?>

	<link rel="stylesheet" type="text/css" href="css/estilos_error404.css" />
	<link rel="stylesheet" type="text/css" href="css/font.css">

</head>
<body>

	<h1>404 Error Pagina</h1>
	<p class="zoom-area"><b>OOPS</b> la pagina que intentas solicitar no esta en el servidor. </p>
	<section class="error-container">
	  <span class="four"><span class="screen-reader-text">4</span></span>
	  <span class="zero"><span class="screen-reader-text">0</span></span>
	  <span class="four"><span class="screen-reader-text">4</span></span>
	</section>
	<div class="link-container">
	  <a target="_blank" href="logeo.php" class="more-link">Volver</a>
	</div>

</body>
</html>